﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace NetworkUtil
{
    /// <summary>
    /// Authors: Maya and Ryan
    /// </summary>
    public static class Networking
    {
        /////////////////////////////////////////////////////////////////////////////////////////
        // Server-Side Code
        /////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Starts a TcpListener on the specified port and starts an event-loop to accept new clients.
        /// The event-loop is started with BeginAcceptSocket and uses AcceptNewClient as the callback.
        /// AcceptNewClient will continue the event-loop.
        /// </summary>
        /// <param name="toCall">The method to call when a new connection is made</param>
        /// <param name="port">The the port to listen on</param>
        public static TcpListener StartServer(Action<SocketState> toCall, int port) //WORKS
        {
            //Start TCPListener at port (taken from ChatSystem)
            TcpListener listener = new TcpListener(IPAddress.Any, port);
            listener.Start();
            //creates tuple to hold the socketInfo to be utilized in socket at BeginAcceptSocket
            Tuple<TcpListener, Action<SocketState>> listenerDel = new Tuple<TcpListener, Action<SocketState>>(listener, toCall);

            try
            {
                listener.BeginAcceptSocket(AcceptNewClient, listenerDel);//Start accepting clients
            }
            catch (Exception)//If Client is disconnected then set socket erroroccurred to true
            {
                SocketState emptySocket = new SocketState(toCall, null);
                emptySocket.ErrorOccurred = true;
                Console.WriteLine("Unexpected disconnection from a client");
            }
            return listener;
        }

        /// <summary>
        /// To be used as the callback for accepting a new client that was initiated by StartServer, and 
        /// continues an event-loop to accept additional clients.
        ///
        /// Uses EndAcceptSocket to finalize the connection and create a new SocketState. The SocketState's
        /// OnNetworkAction should be set to the delegate that was passed to StartServer.
        /// Then invokes the OnNetworkAction delegate with the new SocketState so the user can take action. 
        /// 
        /// If anything goes wrong during the connection process (such as the server being stopped externally), 
        /// the OnNetworkAction delegate should be invoked with a new SocketState with its ErrorOccurred flag set to true 
        /// and an appropriate message placed in its ErrorMessage field. The event-loop should not continue if
        /// an error occurs.
        ///
        /// If an error does not occur, after invoking OnNetworkAction with the new SocketState, an event-loop to accept 
        /// new clients should be continued by calling BeginAcceptSocket again with this method as the callback.
        /// </summary>
        /// <param name="ar">The object asynchronously passed via BeginAcceptSocket. It must contain a tuple with 
        /// 1) a delegate so the user can take action (a SocketState Action), and 2) the TcpListener</param>
        private static void AcceptNewClient(IAsyncResult ar)
        {
            Tuple<TcpListener, Action<SocketState>> tuplePulled = (Tuple<TcpListener, Action<SocketState>>)ar.AsyncState;//gets tuple out of AysncResult
            TcpListener listener = tuplePulled.Item1;//get Listener out of tuple
            Action<SocketState> delCall = tuplePulled.Item2;//Get Delegate out of tuple

            try
            {
                Socket state = listener.EndAcceptSocket(ar);
                SocketState theSocket = new SocketState(delCall, state);
                theSocket.OnNetworkAction(theSocket);// calling delCall
            }
            catch (Exception)
            {
                SocketState emptySocket = new SocketState(delCall, null);
                emptySocket.ErrorOccurred = true;
                emptySocket.ErrorMessage = "Client Connect Error";
                emptySocket.OnNetworkAction(emptySocket);
                Console.WriteLine(emptySocket.ErrorMessage);
            }
            //// continues an accept loop (started by line 68)
            listener.BeginAcceptSocket(AcceptNewClient, tuplePulled);
        }

        /// <summary>
        /// Stops the given TcpListener.
        /// </summary>
        public static void StopServer(TcpListener listener)
        {
            listener.Stop();
        }

        /////////////////////////////////////////////////////////////////////////////////////////
        // Client-Side Code
        /////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Begins the asynchronous process of connecting to a server via BeginConnect, 
        /// and using ConnectedCallback as the method to finalize the connection once it's made.
        /// 
        /// If anything goes wrong during the connection process, toCall should be invoked 
        /// with a new SocketState with its ErrorOccurred flag set to true and an appropriate message 
        /// placed in its ErrorMessage field. Depending on when the error occurs, this should happen either
        /// in this method or in ConnectedCallback.
        ///
        /// This connection process should timeout and produce an error (as discussed above) 
        /// if a connection can't be established within 3 seconds of starting BeginConnect.
        /// 
        /// </summary>
        /// <param name="toCall">The action to take once the connection is open or an error occurs</param>
        /// <param name="hostName">The server to connect to</param>
        /// <param name="port">The port on which the server is listening</param>
        public static void ConnectToServer(Action<SocketState> toCall, string hostName, int port)
        {

            // Establish the remote endpoint for the socket.
            IPHostEntry ipHostInfo;
            IPAddress ipAddress = IPAddress.None;

            // Determine if the server address is a URL or an IP
            try
            {
                ipHostInfo = Dns.GetHostEntry(hostName);
                bool foundIPV4 = false;
                foreach (IPAddress addr in ipHostInfo.AddressList)
                    if (addr.AddressFamily != AddressFamily.InterNetworkV6)
                    {
                        foundIPV4 = true;
                        ipAddress = addr;
                        break;
                    }
                // Didn't find any IPV4 addresses
                if (!foundIPV4)
                {
                    SocketState emptySocket = new SocketState(toCall, null);
                    emptySocket.ErrorOccurred = true;
                    emptySocket.ErrorMessage = "IP not found";
                    emptySocket.OnNetworkAction(emptySocket);
                    Console.WriteLine(emptySocket.ErrorMessage);
                }
            }
            catch (Exception)
            {
                // see if host name is a valid ipaddress
                try
                {
                    ipAddress = IPAddress.Parse(hostName);
                }
                catch (Exception)
                {

                    SocketState emptySocket = new SocketState(toCall, null);
                    emptySocket.ErrorOccurred = true;
                    emptySocket.ErrorMessage = "Invalid IP was entered";
                    emptySocket.OnNetworkAction(emptySocket);
                    Console.WriteLine(emptySocket.ErrorMessage);
                }
            }

            // Create a TCP/IP socket.
            Socket socket = new Socket(ipAddress.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
            socket.NoDelay = true;

            try
            {
                SocketState state = new SocketState(toCall, socket);
                var result = state.TheSocket.BeginConnect(ipAddress, port, ConnectedCallback, state);//starts connection loop
                bool success = result.AsyncWaitHandle.WaitOne(3000, true);//see if connection times out after 3 seconds
                if (!success)
                {
                    socket.Close();
                }
            }
            catch (Exception)
            {
                SocketState emptySocket = new SocketState(toCall, null);
                emptySocket.ErrorOccurred = true;
                emptySocket.ErrorMessage = "connection failed";
                emptySocket.OnNetworkAction(emptySocket);
                Console.WriteLine(emptySocket.ErrorMessage);
            }
        }

        /// <summary>
        /// To be used as the callback for finalizing a connection process that was initiated by ConnectToServer.
        ///
        /// Uses EndConnect to finalize the connection.
        /// 
        /// As stated in the ConnectToServer documentation, if an error occurs during the connection process,
        /// either this method or ConnectToServer should indicate the error appropriately.
        /// 
        /// If a connection is successfully established, invokes the toCall Action that was provided to ConnectToServer (above)
        /// with a new SocketState representing the new connection.
        /// 
        /// </summary>
        /// <param name="ar">The object asynchronously passed via BeginConnect</param>
        private static void ConnectedCallback(IAsyncResult ar)
        {
            SocketState state = (SocketState)ar.AsyncState;
            lock (state)
            {
                state.OnNetworkAction.Invoke(state);
            }
            try
            {
                state.TheSocket.EndConnect(ar);
            }
            catch (Exception)
            {
                state.ErrorOccurred = true;
                state.ErrorMessage = "The server has not been activated";
                state.OnNetworkAction(state);
            }
        }


        /////////////////////////////////////////////////////////////////////////////////////////
        // Server and Client Common Code
        /////////////////////////////////////////////////////////////////////////////////////////

        /// <summary>
        /// Begins the asynchronous process of receiving data via BeginReceive, using ReceiveCallback 
        /// as the callback to finalize the receive and store data once it has arrived.
        /// The object passed to ReceiveCallback via the AsyncResult should be the SocketState.
        /// 
        /// If anything goes wrong during the receive process, the SocketState's ErrorOccurred flag should 
        /// be set to true, and an appropriate message placed in ErrorMessage, then the SocketState's
        /// OnNetworkAction should be invoked. Depending on when the error occurs, this should happen either
        /// in this method or in ReceiveCallback.
        /// </summary>
        /// <param name="state">The SocketState to begin receiving</param>
        public static void GetData(SocketState state)
        {
            //try catch
            try
            {
                state.TheSocket.BeginReceive(state.buffer, 0, state.buffer.Length, SocketFlags.None, ReceiveCallback, state);
            }
            catch (Exception)
            {
                state.ErrorOccurred = true;
                state.ErrorMessage = "Message could not be received";
                state.OnNetworkAction(state);
            }

        }

        /// <summary>
        /// To be used as the callback for finalizing a receive operation that was initiated by GetData.
        /// 
        /// Uses EndReceive to finalize the receive.
        ///
        /// As stated in the GetData documentation, if an error occurs during the receive process,
        /// either this method or GetData should indicate the error appropriately.
        /// 
        /// If data is successfully received:
        ///  (1) Read the characters as UTF8 and put them in the SocketState's unprocessed data buffer (its string builder).
        ///      This must be done in a thread-safe manner with respect to the SocketState methods that access or modify its 
        ///      string builder.
        ///  (2) Call the saved delegate (OnNetworkAction) allowing the user to deal with this data.
        /// </summary>
        /// <param name="ar"> 
        /// This contains the SocketState that is stored with the callback when the initial BeginReceive is called.
        /// </param>
        private static void ReceiveCallback(IAsyncResult ar)
        {
            SocketState state = (SocketState)ar.AsyncState;
            int numBytes = 0;
            try
            {
                numBytes = state.TheSocket.EndReceive(ar);//sets number of bytes to bytes recieved
            }
            catch (Exception)
            {
                state.ErrorOccurred = true;
                state.ErrorMessage = "Message could not be received";
                state.OnNetworkAction(state);
            }
            if (numBytes == 0)
            {
                state.ErrorOccurred = true;
                state.ErrorMessage = "All clients were closed";
                //Ask Piazza maybe
            }
            else
            {
                try
                {
                    string message = Encoding.UTF8.GetString(state.buffer, 0, numBytes);
                    lock (state.data)
                    {
                        state.data.Append(message);
                    }
                }
                catch (Exception)
                {
                    state.ErrorOccurred = true;
                    state.ErrorMessage = "Message could not";
                    state.OnNetworkAction(state);
                }
                state.OnNetworkAction(state);
            }
        }

        /// <summary>
        /// Begin the asynchronous process of sending data via BeginSend, using SendCallback to finalize the send process.
        /// 
        /// If the socket is closed, does not attempt to send.
        /// 
        /// If a send fails for any reason, this method ensures that the Socket is closed before returning.
        /// </summary>
        /// <param name="socket">The socket on which to send the data</param>
        /// <param name="data">The string to send</param>
        /// <returns>True if the send process was started, false if an error occurs or the socket is already closed</returns>
        public static bool Send(Socket socket, string data)
        {
            if (!socket.Connected)//socket is closed
            {
                return false;
            }
            try
            {
                byte[] messageBytes = Encoding.UTF8.GetBytes(data);
                socket.BeginSend(messageBytes, 0, messageBytes.Length, SocketFlags.None, SendCallback, socket);
            }
            catch (Exception)
            {
                socket.Close();
                return false;
            }

            return true;
        }

        /// <summary>
        /// To be used as the callback for finalizing a send operation that was initiated by Send.
        ///
        /// Uses EndSend to finalize the send.
        /// 
        /// This method must not throw, even if an error occurred during the Send operation.
        /// </summary>
        /// <param name="ar">
        /// This is the Socket (not SocketState) that is stored with the callback when
        /// the initial BeginSend is called.
        /// </param>
        private static void SendCallback(IAsyncResult ar)
        {
            Socket socket = (Socket)ar.AsyncState;
            socket.EndSend(ar);
        }


        /// <summary>
        /// Begin the asynchronous process of sending data via BeginSend, using SendAndCloseCallback to finalize the send process.
        /// This variant closes the socket in the callback once complete. This is useful for HTTP servers.
        /// 
        /// If the socket is closed, does not attempt to send.
        /// 
        /// If a send fails for any reason, this method ensures that the Socket is closed before returning.
        /// </summary>
        /// <param name="socket">The socket on which to send the data</param>
        /// <param name="data">The string to send</param>
        /// <returns>True if the send process was started, false if an error occurs or the socket is already closed</returns>
        public static bool SendAndClose(Socket socket, string data)
        {
            if (!socket.Connected)
            {
                return false;
            }
            try
            {
                byte[] messageBytes = Encoding.UTF8.GetBytes(data);
                socket.BeginSend(messageBytes, 0, messageBytes.Length, SocketFlags.None, SendAndCloseCallback, socket);
            }
            catch (Exception)
            {
                socket.Close();
                return false;
            }

            return true;
        }

        /// <summary>
        /// To be used as the callback for finalizing a send operation that was initiated by SendAndClose.
        ///
        /// Uses EndSend to finalize the send, then closes the socket.
        /// 
        /// This method must not throw, even if an error occurred during the Send operation.
        /// 
        /// This method ensures that the socket is closed before returning.
        /// </summary>
        /// <param name="ar">
        /// This is the Socket (not SocketState) that is stored with the callback when
        /// the initial BeginSend is called.
        /// </param>
        private static void SendAndCloseCallback(IAsyncResult ar)
        {
            Socket socket = (Socket)ar.AsyncState;
            socket.EndSend(ar);
            socket.Close();
        }

    }
}