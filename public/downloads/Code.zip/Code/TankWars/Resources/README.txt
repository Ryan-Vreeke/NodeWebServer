PS8 Read Me
*************************MODEL*************************
The model is composed of several classes. Each one encompasses an aspect of the overall world. Below are these classes and their unique features.
>Tank
	Outside of Tank's Json Fields, which are described in the assignment description, Tank also has one unique field and two methods. Tank also has getters for every field of Tank.
	>colors
		Colors contains all the color options a tank could have. Using %, the GetTankSprite/GetTurrSprite methods use the tank ID to get the color. These colors range from 0-7 in the array. In DrawingPanel, these color names are concatenated with the path and "sprite.png" to access the appropriate sprite.

>Beam
	Contains the Json fields from assignment description.

>CommandClass
	Contains Json fields from assignment. Normalizes tdir in constructor for server to receive.

>Powerups
	Contains Json field from assignment and getters.

>Projectile
	Outside of Projectile's Json Fields, which are described in the assignment description, Projectile also has one unique field and one method. Projectile also has getters for every field of Projectile. This is near identical to the setup of Tank.
	>colors
		Colors contain all the color options a tank could have. Using %, the GetTankSprite/GetTurrSprite methods use the tank ID to get the color. These colors range from 0-7 in the array. In DrawingPanel, these color names are concatenated with the path and "sprite.png" to access the appropriate sprite.

>Wall
	Contains Json fields from assignment and contains getters for these fields. Also determines what the startpoint of the wall is (i.e. the upper left corner) to determine where to start drawing.

>World
	Uses list to compile what assets exist in the game after deserializing all JsonObjects. Below are all the lists:
	Walls
        Powerups
        Tanks
        Projectiles
        Beams
        Size
        Player -> the Tank our world focuses on

*************************CONTROLLER*************************
>GameController
	We'll focus on describing the controller based off its methods.
	>Connect
		Initializes CommandClass variables and player name. Then connects to a server using Networking.ConnectToServer().
	>OnConnect
		Tests for connection error and returns message. Runs Connected() to inform view and sets the SocketState's delegate to ReceiveMessage to begin receiving. Runs GetData().
	>ReceiveMessage
		Since ReceiveMessage() is a loop, will continuously process both messages and inputs. Runs GetData().
	>ProcessInputs
		Creates CommandClass on each run that uses private variables as parameters. Send() the serialized command.
	>ProcessMessages
		Splits messages up. Upon first message received, will create player tank and set world size. Parses each type of object from Json's. Adds each object to their appropriate list's in theWorld object to make rendering in Form and DrawingPanel easier.
	>GetWorld
		Returns World.
	>Close
		Closes server socket.
	>MessageEntered
		Sends player name to server.
	>HandleMoveRequest
		Checks passed Dictionary of Keys and bool to update movement status according to what is being pressed. This is done to ensure there are no breaks in movement if user presses on multiple keys and lifts off one. If nothing is pressed, no movement occurs.
	>HandleMouseMovement
		Sets firing mode.
	>HandleMouseRequest
		Set to the MouseMove event handler, this method gets mouse location and sets turret direction to it.
	>CancelMouse
		Won't shoot after player lifts off mouse.

*************************VIEW*************************
>Form1
	Initializes all components of the form, including DrawingPanel.
	>HandleConnected
		Activated by Controller and runs MessageEntered.
	>StartClick
		Disables all controls and uses the controller to connect with the View server address and user name.
	>OnFrame
		Activated by Controller. Counts frames for animation. Uses a try-catch for invalidator. Despite the slower speed of try catch, since this only activates when the client is closed, this works fine.
	>HandleKeyDown
		Using keys Dictionary, sets certain keys to true or false to indicate which keys are being pressed, since the user can press multiple at a time.
	>ShowError
		Shows a message box with an error.
	>HandleKeyUp
		Similar to KeyDown, uses dictionary, sets keys to false if not pressed. This ensures that tanks are still mobile in case user is pressing multiple keys and only releases one.
	>HandleMouseDown
		Triggers mouse press for firing.
	>BeamReceived
		Handler for controller to send a beam to the DrawingPanel.
	>SendDestruction
		Handler for controller to send destroyed tank to the DrawingPanel.
	>HandleMouseMove
		Finds turret direction when mouse is moved and sends to Controller.
	>HandleMouseUp
		Checks when mouse is not being pressed.

>DrawingPanel
	>FrameCount
		Counts frames for animation timing.
	>DrawObjectWithTransform
		Takes a delegate method which is called in the method and drawn according to the World's coordinates rather than the image's. This makes drawing all images/shapes less repetitive.
	>WallDrawer
		Draws all walls. Discerns if walls are horizontal or vertical and iterates over the length to draw the correct amount of wall blocks.
	>PlayerDrawer
		Draws tanks with the appropriate sprite.
	>TurretDrawer
		Draws turrets with appropriate sprite.
	>PowerupDrawer
		Draws powerups with two circles.
	>ProjectileDrawer
		Draws projectile using correctly colored sprites.
	>OnPaint
		Loops through each instance of each object in the world. Players are drawn in the following order: 
		tank -> turret -> player name + score -> health bar
		Health bar uses an if statement to determine the color to draw the bar. If the tank has 2 health left, it's yellow. If there's 1, it's orange. Locks each list to avoid race conditions.
		Stacks are used for DeathAnimations and BeamAnimations. This is to easily remove the oldest animation and activate each animation in LIFO.
	>RemoveAnimation
		Removes all animations of both beams and tanks to save memory and make space for new animations.
	>NewBeam
		Add new beam animation using parametrized beam to the world to run animation.
	>RemoveTank
		Add tank to explosions list to run animation.

>BeamAnimation
	>Draw
		For the amount of frames the animation was constructed with, the panel will draw two lines: one that is white and only about 2-3 pixels wide and another that is light blue and only about 11-13 pixels wide. These are ranges because the width of the beam fluctuates depending on the frame. This was to give a pulsing effect.

>TankDeathAnimation
	>Constructor
		Creates an array of particles as indicated by the parameter. This array contains an assortment of vectors. This is to create direction for the particles to travel in once the animation begins.
	>Draw
		For the amount of frames the animation was constructed with, the panel will draw a predetermined amount of ellipses (as seen in constructor). Two rectangles will be made with random coordinates and will overlap to create a red-orange circle. In the for loop, each explosion effect will change to create multiple explosions around the tank.
	
		
