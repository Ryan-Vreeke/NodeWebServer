﻿using Model;
using NetworkUtil;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text.RegularExpressions;
using System.Threading;
using System.Xml;
using TankWars;

namespace Server
{
    class GameServer
    {
        private Dictionary<long, SocketState> clients;
        private World theWorld;
        private int msPerFrame;

        static void Main(string[] args)
        {
            Stopwatch watch = new Stopwatch();
            GameServer server = new GameServer();
            server.StartServer();

            watch.Start();
            while (true)
            {
                while (watch.Elapsed.TotalMilliseconds < server.msPerFrame)
                { }
                watch.Restart();

                server.Update();
                server.SendToClient();
            }
        }

        private GameServer()
        {
            clients = new Dictionary<long, SocketState>();
            theWorld = new World();
            ReadSettings();
        }

        private void Update() //should update all object locations??? MAYA
        {

        }

        private void SendToClient() //should send client all locations of objects except walls lol Maya
        {
            lock (clients)
            {
                foreach (SocketState client in clients.Values)
                {
                    lock (theWorld)
                    {
                        foreach (Tank tank in theWorld.GetTanks().Values)
                        {
                            Networking.SendAndClose(client.TheSocket, JsonConvert.SerializeObject(tank) + "\n"); //cahn't remember for sure; close after each send?? MAYA
                        }
                    }
                    lock (theWorld)
                    {
                        foreach (Projectile proj in theWorld.GetProjectiles().Values)
                        {
                            Networking.SendAndClose(client.TheSocket, JsonConvert.SerializeObject(proj) + "\n"); //ALSO WHAT ABOUT BEAMS??? MAYA
                        }
                    }
                }
            }

        }

        private void StartServer()
        {
            Networking.StartServer(NewClientConnected, 11000);
            Console.WriteLine("Server is running. Accepting Clients.");
        }

        private void NewClientConnected(SocketState state)
        {
            if (state.ErrorOccurred)
                return;

            lock (clients)
            {
                clients[state.ID] = state;
            }

            Console.WriteLine("Accepted new connection");

            state.OnNetworkAction = ReceivePlayerName;
            Networking.GetData(state);
        }

        private void ReceivePlayerName(SocketState state)
        {
            if (state.ErrorOccurred)
            {
                RemoveClient(state.ID);
                return;
            }

            ProcessName(state);

            state.OnNetworkAction = ReceiveClientData;
            Networking.GetData(state);

        }

        private void ReceiveClientData(SocketState state)
        {
            if (state.ErrorOccurred)
            {
                RemoveClient(state.ID);
                return;
            }


            ProcessClientData(state);

            state.OnNetworkAction = ReceiveClientData;
            Networking.GetData(state);
        }

        private void RemoveClient(long id)
        {
            Console.WriteLine("Client " + id + " disconnected");
            lock (clients)
            {
                clients.Remove(id);
            }
        }


        /// <summary>
        /// Given the data that has arrived so far, 
        /// potentially from multiple receive operations, 
        /// determine if we have enough to make a complete message,
        /// and process it (print it and broadcast it to other clients).
        /// </summary>
        /// <param name="sender">The SocketState that represents the client</param>
        private void ProcessName(SocketState state)
        {
            string totalData = state.GetData();
            string[] parts = Regex.Split(totalData, @"(?<=[\n])");

            // Loop until we have processed all messages.
            // We may have received more than one.
            foreach (string p in parts)
            {
                // Ignore empty strings added by the regex splitter
                if (p.Length == 0)
                    continue;
                // The regex splitter will include the last string even if it doesn't end with a '\n',
                // So we need to ignore it if this happens. 
                if (p[p.Length - 1] != '\n')
                    break;

                Console.WriteLine("Player(" + state.ID + ") \"" + p.Substring(0, p.Length - 1) + "\" joined");

                // Remove it from the SocketState's growable buffer
                state.RemoveData(0, p.Length);
            }

        }

        /// <summary>
        /// Process any buffered messages separated by '\n'
        /// Then inform the view
        /// </summary>
        /// <param name="state"></param>
        private void ProcessClientData(SocketState state)
        {
            string totalData = state.GetData();
            string[] parts = Regex.Split(totalData, @"(?<=[\n])");

            // Loop until we have processed all messages.
            // We may have received more than one.

            List<string> newMessages = new List<string>();

            foreach (string p in parts)
            {
                // Ignore empty strings added by the regex splitter
                if (p.Length == 0)
                    continue;
                // The regex splitter will include the last string even if it doesn't end with a '\n',
                // So we need to ignore it if this happens. 
                if (p[p.Length - 1] != '\n')
                    break;

                // build a list of messages to send to the view
                newMessages.Add(p);

                // Then remove it from the SocketState's growable buffer
                state.RemoveData(0, p.Length);
            }

            foreach (string jsonstring in newMessages)
            {
                //Get All walls
                JObject obj = JObject.Parse(jsonstring);
                CommandClass rebuilt = JsonConvert.DeserializeObject<CommandClass>(jsonstring);
                lock (theWorld)
                {
                    switch (rebuilt.Fire)
                    {
                        case "main":
                            //proj method MAYA
                            break;
                        case "alt":
                            //beam method MAYA
                            break;
                        case "none":
                            //NOTHING :)
                            break;
                    }
                    switch (rebuilt.Moving)
                    {
                        case "up":
                            break;
                        case "down":
                            break;
                        case "left":
                            break;
                        case "right":
                            break;
                    }
                    theWorld.GetTanks()[(int)state.ID].SetTurrDir(rebuilt.Tdir);
                }
                    
            }

        }


        private void ReadSettings()
        {
            string xmlPath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.Parent.FullName;
            string xmlFile = xmlPath + "\\Resources\\Libraries\\settings.xml";
            XmlTextReader reader = new XmlTextReader(xmlFile);
            reader.WhitespaceHandling = WhitespaceHandling.None;
            reader.Read();

            Vector2D p1 = null;
            Vector2D p2 = null;
            double x = 0;
            double y = 0;
            int wallId = 0;

            bool defaultSettings = true;

            while (reader.Read() && defaultSettings)
            {
                switch (reader.Name)
                {
                    case "UniverseSize":
                        reader.Read();
                        theWorld.Size = Int32.Parse(reader.Value);
                        break;
                    case "MSPerFrame":
                        reader.Read();
                        msPerFrame = Int32.Parse(reader.Value);
                        break;
                    case "FramesPerShot":
                        reader.Read();
                        break;
                    case "RespawnRate":
                        reader.Read();
                        break;
                }
                if (!Double.TryParse(reader.Value, out x))
                {
                    defaultSettings = false;
                }
                else
                {
                    reader.Read();
                }
            }
            while (reader.Read())
            {
                if (reader.IsStartElement())
                {
                    switch (reader.Name)
                    {
                        case "Wall":
                            if (p1 != null && p2 != null) //checks for first occurrence of wall
                            {
                                theWorld.GetWalls().Add(new Wall(wallId, p1, p2));
                                wallId++;
                                p1 = null;
                                p2 = null;
                            }
                            break;
                        case "p1":
                            while (p1 == null && reader.Read())
                            {
                                if (reader.IsStartElement())
                                {
                                    switch (reader.Name)
                                    {
                                        case "x":
                                            reader.Read();
                                            Double.TryParse(reader.Value, out x);
                                            break;
                                        case "y":
                                            reader.Read();
                                            Double.TryParse(reader.Value, out y);
                                            p1 = new Vector2D(x, y);
                                            break;
                                    }
                                }
                            }
                            break;
                        case "p2":
                            while (p2 == null && reader.Read())
                            {
                                if (reader.IsStartElement())
                                {
                                    switch (reader.Name)
                                    {
                                        case "x":
                                            reader.Read();
                                            Double.TryParse(reader.Value, out x);
                                            break;
                                        case "y":
                                            reader.Read();
                                            Double.TryParse(reader.Value, out y);
                                            p2 = new Vector2D(x, y);
                                            break;
                                    }
                                }
                            }
                            break;
                    }
                }

            }
            theWorld.GetWalls().Add(new Wall(wallId, p1, p2));
        }
    }
}
