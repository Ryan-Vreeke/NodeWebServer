﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Model
{
    /*
     * Contains all iterations of tanks, powerups, and walls
     * Only class modified by controller
     */

    public class World
    {
        private List<Wall> walls;
        private Dictionary<int, Powerups> pUps;
        private Dictionary<int, Tank> tanks;
        private Dictionary<int, Projectile> projectiles;
        private int size;
        private Tank player;

        private const int maxUps = 3;

        /// <summary>
        /// default constructor for world class
        /// </summary>
        public World()
        {
            tanks = new Dictionary<int, Tank>();
            walls = new List<Wall>();
            projectiles = new Dictionary<int, Projectile>();
            pUps = new Dictionary<int, Powerups>();
        }


        public int Size { get { return size; } set { this.size = value; } }
        /// <summary>
        /// returns the local players tank 
        /// </summary>
        /// <returns>Tank</returns>
        public Tank GetPlayer()
        {
            return player;
        }
        /// <summary>
        /// sets player
        /// </summary>
        /// <param name="player"></param>
        public void SetPlayer(Tank player)
        {
            this.player = player;
        }
        /// <summary>
        /// set size of the world
        /// </summary>
        /// <param name="size"></param>
        public void SetSize(int size)
        {
            this.size = size;
        }
        /// <summary>
        /// returns the list of all projectiles
        /// </summary>
        /// <returns>list</returns>
        public Dictionary<int, Projectile> GetProjectiles()
        {
            return projectiles;
        }
        /// <summary>
        /// returns the list of all tanks
        /// </summary>
        /// <returns>list</returns>
        public Dictionary<int, Tank> GetTanks()
        {
            return tanks;
        }
        /// <summary>
        /// list of all walls
        /// </summary>
        /// <returns>List</returns>
        public List<Wall> GetWalls()
        {
            return walls;
        }
        /// <summary>
        /// list of all powerups
        /// </summary>
        /// <returns>List</returns>
        public Dictionary<int, Powerups> GetPowerups()
        {
            return pUps;
        }
        /// <summary>
        /// returns size of world
        /// </summary>
        /// <returns></returns>
        public int GetSize()
        {
            return size;
        }
    }
}
