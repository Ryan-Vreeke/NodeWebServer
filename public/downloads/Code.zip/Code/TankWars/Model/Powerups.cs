﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TankWars;

namespace Model
{
    [JsonObject(MemberSerialization.OptIn)]
    public class Powerups
    {
        [JsonProperty]
        private int power;
        [JsonProperty]
        private Vector2D loc;
        [JsonProperty]
        private bool died;

        private const int spawnDelay = 1650;

        public Vector2D Loc { get { return loc; } set { this.loc = value; } }

        /// <summary>
        /// Default constructor
        /// </summary>
        public Powerups()
        {

        }
        /// <summary>
        /// contructor for powerups
        /// </summary>
        /// <param name="power"></param>
        /// <param name="loc"></param>
        public Powerups(int power, Vector2D loc)
        {
            this.power = power;
            this.loc = loc;

        }
        /// <summary>
        /// returns the powerup id
        /// </summary>
        /// <returns></returns>
        public int GetID()
        {
            return power;
        }
        /// <summary>
        /// returns if the power up is dead
        /// </summary>
        /// <returns></returns>
        public bool isDied()
        {
            return died;
        }

    }
}
