﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TankWars;

namespace Model
{
    [JsonObject(MemberSerialization.OptIn)]
    public class CommandClass
    {
        [JsonProperty]
        private string moving;
        [JsonProperty]
        private string fire;
        [JsonProperty]
        private Vector2D tdir; //must be normalized
        /// <summary>
        /// default contructor
        /// </summary>
        public CommandClass() { }
        /// <summary>
        /// contructor for a command to be sent to the sever
        /// </summary>
        /// <param name="moving"></param>
        /// <param name="fire"></param>
        /// <param name="tdir"></param>
        public CommandClass(string moving, string fire, Vector2D tdir)
        {
            this.moving = moving;
            this.fire = fire;
            tdir.Normalize();
            this.tdir = tdir;
        }

        public Vector2D Tdir { get { return tdir; } set { this.tdir = value; } }
        public string Moving { get { return moving; } set { this.moving = value; } }
        public string Fire { get { return fire; } set { this.fire = value; } }

    }
}
