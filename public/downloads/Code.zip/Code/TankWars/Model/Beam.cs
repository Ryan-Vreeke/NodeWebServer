﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TankWars;

namespace Model
{
    [JsonObject(MemberSerialization.OptIn)]
    public class Beam
    {
        [JsonProperty]
        private int beam;
        [JsonProperty]
        private Vector2D org;
        [JsonProperty]
        private Vector2D dir;
        [JsonProperty]
        private int owner;

        public Vector2D Origin { get { return org; } set { org = value; } }
        public Vector2D Dir { get { return dir; } set { dir = value; } }
        /// <summary>
        /// empty constructor
        /// </summary>
        public Beam() { }
        /// <summary>
        /// makes a new beam using passed in fields
        /// </summary>
        /// <param name="beam"></param>
        /// <param name="owner"></param>
        /// <param name="org"></param>
        /// <param name="dir"></param>
        public Beam(int beam, int owner, Vector2D org, Vector2D dir)
        {
            this.beam = beam;
            this.owner = owner;
            this.org = org;
            this.dir = dir;
        }
    }
}
