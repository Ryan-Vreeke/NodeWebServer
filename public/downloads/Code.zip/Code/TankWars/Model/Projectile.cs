﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TankWars;

namespace Model
{
    [JsonObject(MemberSerialization.OptIn)]
    public class Projectile
    {
        [JsonProperty]
        private int proj;
        [JsonProperty]
        private Vector2D loc;
        [JsonProperty]
        private Vector2D dir;
        [JsonProperty]
        private bool died;
        [JsonProperty]
        private int owner;
        private string[] colors;

        private const int projSpeed = 25;
        private Vector2D projVelocity;

        public Vector2D Loc { get { return loc; } set { loc = value; } }
        public Vector2D Dir { get { return dir; } set { dir = value; } }
        /// <summary>
        /// default constructor
        /// </summary>
        public Projectile()
        {
            colors = new string[] { "blue", "green", "white", "grey", "violet","brown", "red", "yellow" };
        }
        /// <summary>
        /// contructor for projectiles
        /// </summary>
        /// <param name="proj"></param>
        /// <param name="owner"></param>
        public Projectile(int proj, int owner)
        {
            this.proj = proj;
            this.owner = owner;

            colors = new string[] { "Blue", "Green", "LightGreen", "Dark", "Purple", "Orange", "Red", "Yellow" };
        }
        /// <summary>
        /// returns the sprite of the shot
        /// </summary>
        /// <returns></returns>
        public string GetShotSprite()
        {
            return ("shot-" + colors[owner % 8] + ".png");
        }
        /// <summary>
        /// returns if the projectile is dead
        /// </summary>
        /// <returns></returns>
        public bool isDied()
        {
            return died;
        }
        /// <summary>
        /// returns the id of the projectile
        /// </summary>
        /// <returns></returns>
        public int GetID()
        {
            return proj;
        }
    }
}
