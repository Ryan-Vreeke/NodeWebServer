﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TankWars;

namespace Model
{
    /**
     * A class with an iteration for every client connected to the server
     * Should have 8 unique appearances for 8 players
     * 
     */
    [JsonObject(MemberSerialization.OptIn)]
    public class Tank
    {
        [JsonProperty]
        private int tank; //id
        [JsonProperty]
        private string name; //player name
        [JsonProperty]
        private Vector2D loc;
        [JsonProperty]
        private Vector2D bdir;
        [JsonProperty]
        private Vector2D tdir;
        [JsonProperty]
        private int score;
        [JsonProperty]
        private int hp;
        [JsonProperty]
        private bool died;
        [JsonProperty]
        private bool dc;
        [JsonProperty]
        private bool join;

        private const int startHp = 3; //MT
        private const double travelSpeed = 3.0;
        private Vector2D tankVelocity;
        private const int tankSize = 60;

        private string[] colors;
        /// <summary>
        /// default constructor 
        /// </summary>
        public Tank()
        {
            colors = new string[] { "Blue", "Green", "LightGreen", "Dark", "Purple", "Orange", "Red", "Yellow" };//array of all possible colors
        }

        public Tank(int tank, string name)
        {
            this.tank = tank;
            this.name = name;
            this.hp = startHp; //MT
            this.tankVelocity = new Vector2D(0, 0);
            this.bdir = new Vector2D(1, 0);
            this.tdir = new Vector2D(0, 1);

            colors = new string[] { "Blue", "Green", "LightGreen", "Dark", "Purple", "Orange", "Red", "Yellow" };

        }

        public string Name { get { return name;  } set { this.name = value; } }

        public Vector2D Loc { get { return loc; } set { this.loc = value; } }

        public Vector2D Ori { get { return bdir; } set { this.bdir = value; } }
        /// <summary>
        /// score of the current tank
        /// </summary>
        public int Score { get { return score; } set { this.score = value; } }
        /// <summary>
        /// returns if the tank is alive or not
        /// </summary>
        /// <returns></returns>
        public bool IsDied()
        {
            return died;
        }
        /// <summary>
        /// returns is the tank has been disconnected
        /// </summary>
        /// <returns></returns>
        public bool IsDisconnect()
        {
            return dc;
        }
        /// <summary>
        /// returns the id of the tank
        /// </summary>
        /// <returns></returns>
        public int GetID()
        {
            return tank;
        }
        /// <summary>
        /// returns the file name of the tanks sprite
        /// </summary>
        /// <returns></returns>
        public string GetTankSprite()
        {
            return (colors[tank % 8] + "Tank.png");
        }
        /// <summary>
        /// returns the file name of the turret sprite. the color is based on tank id
        /// </summary>
        /// <returns></returns>
        public string GetTurrSprite()
        {
            return (colors[tank % 8] + "Turret.png");
        }
        /// <summary>
        /// gets the turrets direction vector
        /// </summary>
        /// <returns></returns>
        public Vector2D GetTurrDir()
        {
            return tdir;
        }

        /// <summary>
        /// gets the color of the tanks using the tank id
        /// </summary>
        /// <returns></returns>
        public string GetColor()
        {
            return colors[tank % 8];
        }
        /// <summary>
        /// returns the current hp of the tank
        /// </summary>
        /// <returns></returns>
        public int GetHp()
        {
            return hp;
        }

        public void SetTurrDir(Vector2D tdir)
        {
            this.tdir = tdir;
        }

        //MAYA IS DUMB SHE DON"T KNOW PHYSICS BULLSHIT
        public void TankMovement()
        {

        }
    }
}
