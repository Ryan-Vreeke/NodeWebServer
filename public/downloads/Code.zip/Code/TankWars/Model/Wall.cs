﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using TankWars;

namespace Model
{
    /**
     * A class representing the wall objects. Should be a static class.
     * 
     * Component: Collision
 */
    [JsonObject(MemberSerialization.OptIn)]
    public class Wall
    {

        [JsonProperty]
        private int wall;
        [JsonProperty]
        private Vector2D p1;
        [JsonProperty]
        private Vector2D p2;

        private const int wallSize = 50;


        /// <summary>
        /// default contructor
        /// </summary>
        public Wall()
        {


        }
        /// <summary>
        /// contructor for wall
        /// </summary>
        /// <param name="wall"></param>
        /// <param name="p1"></param>
        /// <param name="p2"></param>
        public Wall(int wall, Vector2D p1, Vector2D p2)
        {
            this.wall = wall;
            this.p1 = p1;
            this.p2 = p2;
        }
        /// <summary>
        /// gets the start point for the wall
        /// </summary>
        /// <returns>vector2D</returns>
        public Vector2D GetStartpoint()
        {
            double x = 0;
            double y = 0;

            if (p1.GetX() < p2.GetX() || p1.GetY() < p2.GetY())//checks what the smallest point is
            {
                x = p1.GetX();
                y = p1.GetY();
            }
            else
            {
                x = p2.GetX();
                y = p2.GetY();
            }

            return new Vector2D(x, y);//creates a new vector2D using the smalled point
        }

        /// <summary>
        /// Returns the direction of the wall. If true then the wall is horizontal, if false the wall is vertical
        /// </summary>
        /// <returns>bool</returns>
        public bool GetDirection()
        {
            //if p1 x is the same as p2 x then the wall is Vertical
            if (p1.GetX() == p2.GetX())
                return false;
            else
                return true;//if x is different then the wall is Horizontal
        }

        /// <summary>
        /// returns the number of sections needed to draw the full wall
        /// </summary>
        /// <returns>double</returns>
        public int GetLength(int section)
        {
            if (GetDirection())
            {
                return (int)(GetWidth() / section);
            }
            else
                return (int)(GetHeight() / section);
        }

        /// <summary>
        /// gets the height of the wall based on p1 and p2 
        /// </summary>
        /// <returns>double<returns>
        public double GetHeight()
        {
            return Math.Abs(p1.GetY() - p2.GetY());
        }

        /// <summary>
        /// gets the width of wall based on p1 and p2
        /// </summary>
        /// <returns>double</returns>
        public double GetWidth()
        {
            return Math.Abs(p1.GetX() - p2.GetX());
        }
    }
}
