﻿using Model;
using NetworkUtil;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using TankWars;

namespace GameController
{
    public class GameController
    {
        //Contoller events that the view can subscribe to
        public delegate void ConnectedHandler();
        public event ConnectedHandler Connected;

        public delegate void ErrorHandler(string err);
        public event ErrorHandler Error;

        private Tank pTank;
        private string pName;
        private bool isFirst;

        private string fireMode;
        private string moveDir;
        private Vector2D turrDir;

        private World theWorld = new World();

        public delegate void ServerUpdateHandler();

        public event ServerUpdateHandler UpdateArrived;

        public delegate void BeamSend(Beam sent);
        public delegate void TankDeath(Tank tank);
        public event TankDeath DestroyTank;
        public event BeamSend SendBeam;
        


        /// <summary>
        /// State representing the connection with the server
        /// </summary>
        SocketState theServer = null;

        /// <summary>
        /// Begins the process of connecting to the server
        /// </summary>
        /// <param name="addr"></param>
        public void Connect(string addr, string name)
        {
            pName = name;
            turrDir = new Vector2D();
            moveDir = "none";
            fireMode = "none";
            Networking.ConnectToServer(OnConnect, addr, 11000);
        }

        /// <summary>
        /// Method to be invoked by the networking library when a connection is made
        /// </summary>
        /// <param name="state"></param>
        private void OnConnect(SocketState state)
        {
            if (state.ErrorOccurred)
            {
                // inform the view
                Error("Error connecting to server");
                return;
            }


            theServer = state;
            isFirst = true;

            // inform the view
            Connected();

            // Start an event loop to receive messages from the server
            state.OnNetworkAction = ReceiveMessage;
            Networking.GetData(state);
        }

        /// <summary>
        /// Method to be invoked by the networking library when 
        /// data is available
        /// </summary>
        /// <param name="state"></param>
        private void ReceiveMessage(SocketState state)
        {
            if (state.ErrorOccurred)
            {
                // inform the view
                Error("Lost connection to server");
                return;
            }

            ProcessMessages(state);
            ProcessInputs();

            // Continue the event loop
            // state.OnNetworkAction has not been changed, 
            // so this same method (ReceiveMessage) 
            // will be invoked when more data arrives
            Networking.GetData(state);
        }

        /// <summary>
        /// Checks which inputs are currently held down
        /// Normally this would send a message to the server
        /// </summary>
        private void ProcessInputs()
        {


            CommandClass cmd = new CommandClass(moveDir, fireMode, turrDir);
            Networking.Send(theServer.TheSocket, JsonConvert.SerializeObject(cmd) + "\n");
        }

        /// <summary>
        /// Process any buffered messages separated by '\n'
        /// Then inform the view
        /// </summary>
        /// <param name="state"></param>
        private void ProcessMessages(SocketState state)
        {


            string totalData = state.GetData();
            string[] parts = Regex.Split(totalData, @"(?<=[\n])");

            // Loop until we have processed all messages.
            // We may have received more than one.

            List<string> newMessages = new List<string>();

            foreach (string p in parts)
            {
                // Ignore empty strings added by the regex splitter
                if (p.Length == 0)
                    continue;
                // The regex splitter will include the last string even if it doesn't end with a '\n',
                // So we need to ignore it if this happens. 
                if (p[p.Length - 1] != '\n')
                    break;

                // build a list of messages to send to the view
                newMessages.Add(p);

                // Then remove it from the SocketState's growable buffer
                state.RemoveData(0, p.Length);
            }

            foreach (string jsonstring in newMessages)
            {
                int result;
                if (int.TryParse(jsonstring, out result))
                {
                    if (isFirst)
                    {
                        pTank = new Tank(result, pName);
                        isFirst = false;
                    }
                    else
                    {
                        theWorld.SetSize(result);
                    }
                }
                else
                {
                    //Get All walls
                    JObject obj = JObject.Parse(jsonstring);
                    JToken token = obj["wall"];

                    if (token != null)
                    {
                        Wall rebuilt = JsonConvert.DeserializeObject<Wall>(jsonstring);
                        lock (theWorld)
                            theWorld.GetWalls().Add(rebuilt);
                    }
                    //Get all Tanks
                    token = obj["tank"];

                    if (token != null)
                    {
                        Tank rebuilt = JsonConvert.DeserializeObject<Tank>(jsonstring);
                        lock (theWorld)
                        {
                            if (!theWorld.GetTanks().ContainsKey(rebuilt.GetID()))
                            {
                                theWorld.GetTanks().Add(rebuilt.GetID(), rebuilt);
                            }
                            else
                            {
                                if (rebuilt.IsDied() || rebuilt.IsDisconnect())
                                {
                                    theWorld.GetTanks().Remove(rebuilt.GetID());
                                    DestroyTank(rebuilt);
                                }
                                else
                                {
                                    theWorld.GetTanks()[rebuilt.GetID()] = rebuilt;
                                }
                            }
                            if(theWorld.GetTanks().ContainsKey(pTank.GetID()))
                                theWorld.SetPlayer(theWorld.GetTanks()[pTank.GetID()]);
                        }
                    }

                    //Get All projectiles 
                    token = obj["proj"];

                    if (token != null)
                    {
                        Projectile rebuilt = JsonConvert.DeserializeObject<Projectile>(jsonstring);
                        lock (theWorld)
                        {
                            if (theWorld.GetProjectiles().ContainsKey(rebuilt.GetID()))
                                theWorld.GetProjectiles()[rebuilt.GetID()] = rebuilt;
                            else
                                theWorld.GetProjectiles().Add(rebuilt.GetID(), rebuilt);

                            if (rebuilt.isDied())
                                theWorld.GetProjectiles().Remove(rebuilt.GetID());

                        }

                    }
                    //Get All powerups
                    token = obj["power"];

                    if (token != null)
                    {
                        Powerups rebuilt = JsonConvert.DeserializeObject<Powerups>(jsonstring);
                        lock (theWorld)
                        {
                            if (!theWorld.GetPowerups().ContainsKey(rebuilt.GetID()))
                                theWorld.GetPowerups().Add(rebuilt.GetID(), rebuilt);
                            if (rebuilt.isDied())
                                theWorld.GetPowerups().Remove(rebuilt.GetID());

                        }
                    }
                    //Get All beams
                    token = obj["beam"];

                    if (token != null)
                    {
                        Beam rebuilt = JsonConvert.DeserializeObject<Beam>(jsonstring);
                        SendBeam(rebuilt);
                    }
                }
            }

            // Notify any listeners (the view) that a new game world has arrived from the server
            lock (this)
            {
                if (UpdateArrived != null)
                    UpdateArrived();
            }

            // inform the view

        }

        /// <summary>
        /// Returns the world object
        /// </summary>
        /// <returns></returns>
        public World GetWorld()
        {
            return theWorld;
        }

        /// <summary>
        /// Closes the connection with the server
        /// </summary>
        public void Close()
        {
            theServer?.TheSocket.Close();
        }

        /// <summary>
        /// Send a message to the server
        /// </summary>
        /// <param name="message"></param>
        public void MessageEntered(string message)
        {
            pName = message;
            Networking.Send(theServer.TheSocket, message + "\n");

        }

        /// <summary>
        /// handling movement request
        /// </summary>
        public void HandleMoveRequest(Dictionary<string, bool> keys)
        {
            int pressed = 0;
            foreach (KeyValuePair<string, bool> press in keys)
            {
                if (press.Value == true)
                {
                    moveDir = press.Key;
                    return;
                }
                else
                {
                    pressed++;
                }
            }
            if (pressed == 4)
            {
                moveDir = "none";
            }
        }


        /// <summary>
        /// handling mouse request
        /// </summary>
        public void HandleMouseRequest(string mode)
        {
            fireMode = mode;
        }


        /// <summary>
        /// handling mouse request
        /// </summary>
        public void HandleMouseRequest(Vector2D mouseLoc)
        {
            turrDir = mouseLoc;

        }

        /// <summary>
        /// Example of canceling mouse request
        /// </summary>
        public void CancelMouseRequest()
        {
            fireMode = "none";
        }
    }
}
