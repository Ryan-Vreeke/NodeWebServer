﻿using Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using TankWars;

namespace View
{
    public partial class Form1 : Form
    {
        // The controller handles updates from the "server"
        // and notifies us via an event
        private GameController.GameController theController;

        // World is a simple container for Players and Powerups
        // The controller owns the world, but we have a reference to it
        private World theWorld;
        private Dictionary<string, bool> keys;

        // This simple form only has two components
        DrawingPanel drawingPanel;
        Button startButton;
        Label nameLabel;
        Label addressLabel;
        TextBox nameText;
        TextBox serverAddress;
       
        private const int viewSize = 900;
        private const int menuSize = 40;
        private int frameCount = 0;

        public delegate void FrameCounter(int Frames);
        public event FrameCounter FrameArrives;

        public Form1(GameController.GameController ctl)
        {
            InitializeComponent();

            theController = ctl;
            theWorld = theController.GetWorld();
            keys = new Dictionary<string, bool>();
            keys.Add("up", false);
            keys.Add("left", false);
            keys.Add("right", false);
            keys.Add("down", false);

            // register handlers for the controller's events
            theController.Error += ShowError;
            theController.Connected += HandleConnected;
            theController.UpdateArrived += OnFrame;
            theController.SendBeam += BeamRecieved;
            theController.DestroyTank += SendDestruction;

            // Set up the form.
            // This stuff is usually handled by the drag and drop designer,
            // but it's simple enough for this lab.

            // Set the window size
            ClientSize = new Size(viewSize, viewSize + menuSize);

            // Place and add the button
            startButton = new Button();
            startButton.Location = new Point(215, 5);
            startButton.Size = new Size(70, 20);
            startButton.Text = "Start";
            startButton.Click += StartClick;
            this.Controls.Add(startButton);

            // Place and add the drawing panel RYAN
            drawingPanel = new DrawingPanel(theWorld, this);
            drawingPanel.Location = new Point(0, menuSize);
            drawingPanel.Size = new Size(viewSize, viewSize);
            this.Controls.Add(drawingPanel);

            // Place and add the name label
            nameLabel = new Label();
            nameLabel.Text = "Name:";
            nameLabel.Location = new Point(5, 10);
            nameLabel.Size = new Size(40, 15);
            this.Controls.Add(nameLabel);

            // Place and add the address label
            addressLabel = new Label();
            addressLabel.Text = "Address:";
            addressLabel.Location = new Point(370, 10);
            addressLabel.Size = new Size(50, 15);
            this.Controls.Add(addressLabel);

            // Place an Address bar
            serverAddress = new TextBox();
            serverAddress.Text = "localhost";
            serverAddress.Location = new Point(425, 5);
            serverAddress.Size = new Size(70, 20);
            this.Controls.Add(serverAddress);

            // Place and add the name textbox
            nameText = new TextBox();
            nameText.Text = "player";
            nameText.Location = new Point(50, 5);
            nameText.Size = new Size(70, 15);
            this.Controls.Add(nameText);

            // Set up key and mouse handlers
            this.KeyDown += HandleKeyDown;
            this.KeyUp += HandleKeyUp;
            drawingPanel.MouseDown += HandleMouseDown;
            drawingPanel.MouseUp += HandleMouseUp;
            drawingPanel.MouseMove += HandleMouseMove;

            

        }

        /// <summary>
        /// Handler for the controller's Connected event
        /// </summary>
        private void HandleConnected()
        {
            Console.WriteLine("connected");
            theController.MessageEntered(nameText.Text);
        }

        /// <summary>
        /// Simulates connecting to a "server"
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void StartClick(object sender, EventArgs e)
        {
            if (serverAddress.Text == "")
            {
                MessageBox.Show("Please enter a server address");
                return;
            }

            // Disable the controls and try to connect
            startButton.Enabled = false;
            serverAddress.Enabled = false;

            theController.Connect(serverAddress.Text, nameText.Text);
            nameText.Enabled = false;
        }

        /// <summary>
        /// Handler for the controller's UpdateArrived event
        /// </summary>
        private void OnFrame()
        {
            frameCount++;
            FrameArrives(frameCount);

            // Invalidate this form and all its children
            // This will cause the form to redraw as soon as it can
            if (this != null)
            {
                MethodInvoker invalidator = new MethodInvoker(() => this.Invalidate(true));
                this.Invoke(invalidator);
            }
        }

        /// <summary>
        /// Key down handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HandleKeyDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Escape)
                Application.Exit();
            if (e.KeyCode == Keys.W)
                keys["up"] = true;
            if (e.KeyCode == Keys.A)
                keys["left"] = true;
            if (e.KeyCode == Keys.S)
                keys["down"] = true;
            if (e.KeyCode == Keys.D)
                keys["right"] = true;

            theController.HandleMoveRequest(keys);
            // Prevent other key handlers from running
            e.SuppressKeyPress = true;
            e.Handled = true;
        }

        /// <summary>
        /// Handler for the controller's Error event
        /// </summary>
        /// <param name="err"></param>
        private void ShowError(string err)
        {
            // Show the error
            MessageBox.Show(err);
            // Then re-enable the controlls so the user can reconnect
            this.Invoke(new MethodInvoker(
              () =>
              {
                  startButton.Enabled = true;
                  serverAddress.Enabled = true;
              }));
        }

        /// <summary>
        /// Key up handler
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HandleKeyUp(object sender, KeyEventArgs e)
        {
            //need to move without stopping
            if (e.KeyCode == Keys.Escape)
                Application.Exit();
            if (e.KeyCode == Keys.W)
                keys["up"] = false;
            if (e.KeyCode == Keys.A)
                keys["left"] = false;
            if (e.KeyCode == Keys.S)
                keys["down"] = false;
            if (e.KeyCode == Keys.D)
                keys["right"] = false;

            theController.HandleMoveRequest(keys);
        }

        /// <summary>
        /// Handle mouse down
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HandleMouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
                theController.HandleMouseRequest("main");
            if (e.Button == MouseButtons.Right)
            {
                theController.HandleMouseRequest("alt");
            }
        }

        /// <summary>
        /// Handle Beam sent from server
        /// </summary>
        /// <param name="sent"></param>
        private void BeamRecieved(Beam sent)
        {
            drawingPanel.NewBeam(sent);//sending beam to draw panel
        }

        /// <summary>
        /// Handles tank getting destroyed, by calling an animation drawer in drawpanel
        /// </summary>
        /// <param name="tank"></param>
        private void SendDestruction(Tank tank)
        {
            drawingPanel.RemoveTank(tank);//sending tank to drawpanel
        }

        /// <summary>
        /// handles mouse being moved
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HandleMouseMove(object sender, MouseEventArgs e)
        {
            Vector2D turrDir = new Vector2D(e.X - (viewSize / 2), e.Y - (viewSize / 2));
            // then be sure to normalize it since it's a direction
            turrDir.Normalize();
            theController.HandleMouseRequest(turrDir);
        }

        /// <summary>
        /// Handle mouse up
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void HandleMouseUp(object sender, MouseEventArgs e)
        {
            theController.CancelMouseRequest();
        }
    }
}
