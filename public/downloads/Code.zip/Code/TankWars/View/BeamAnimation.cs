﻿using Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace View
{
    class BeamAnimation
    {
        private Beam beam;
        private int viewSize;
        private int startFrame;
        private int pDuration = 60;
        private bool running;
        /// <summary>
        /// sets the durration of the animation(in fps) every 60 fps is one second
        /// </summary>
        public int Duration { get { return pDuration; } set { pDuration = value; } }
        /// <summary>
        /// returns true if the animations if finished playing
        /// </summary>
        public bool End { get { return !running; }}
        /// <summary>
        /// creates a new beam animation
        /// </summary>
        /// <param name="beam"></param>
        /// <param name="viewSize"></param>
        /// <param name="startFrame"></param>
        public BeamAnimation(Beam beam, int viewSize, int startFrame)
        {
            this.beam = beam;
            this.viewSize = viewSize;
            this.startFrame = startFrame;
        }

        /// <summary>
        /// Draws the animation for the beam
        /// </summary>
        /// <param name="e"></param>
        /// <param name="currentFrame"></param>
        public void Draw(PaintEventArgs e, int currentFrame)
        {
            if (currentFrame < startFrame + pDuration)
            {
                running = true;
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
                beam.Dir.Normalize();
                Pen whitePen = new Pen(Color.White, currentFrame % 3);
                Pen bluePen = new Pen(Color.FromArgb(100, Color.CornflowerBlue), (currentFrame % 2) + 10);
                whitePen.Alignment = PenAlignment.Center;
                bluePen.Alignment = PenAlignment.Center;

                e.Graphics.DrawLine(bluePen, (float)beam.Origin.GetX(), (float)beam.Origin.GetY(), (float)beam.Dir.GetX() * (2 * viewSize), (float)beam.Dir.GetY() * (2 * viewSize));
                e.Graphics.DrawLine(whitePen, (float)beam.Origin.GetX(), (float)beam.Origin.GetY(), (float)beam.Dir.GetX() * (2 * viewSize), (float)beam.Dir.GetY() * (2 * viewSize));
            }
            else
                running = false;
        }
    }
}
