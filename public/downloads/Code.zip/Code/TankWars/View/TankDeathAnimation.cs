﻿using Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TankWars;

namespace View
{

    class TankDeathAnimation
    {
        private Tank tank;
        private int startFrame;
        private int pDuration = 120;
        private bool running;
        private Vector2D[] directions;
        private Rectangle r;
        private Rectangle r1;
        private Random random;

        public int Duration { get { return pDuration; } set { pDuration = value; } }
        public bool End { get { return !running; } }
        /// <summary>
        /// tank animation constructor
        /// </summary>
        /// <param name="tank"></param>
        /// <param name="startFrame"></param>
        /// <param name="particalAmount"></param>
        public TankDeathAnimation(Tank tank, int startFrame, int particalAmount)
        {
            random = new Random();
            this.tank = tank;
            this.startFrame = startFrame;
            directions = new Vector2D[particalAmount];

            for (int i = 0; i < directions.Length; i++)//creates an array of random direction vectors
            {
                double x = random.NextDouble();
                double y = random.NextDouble();
                int t = random.Next(0, 4);
                if (t == 0)
                {
                    x = -x;
                }
                if (t == 3)
                {
                    y = -y;
                }
                Vector2D tempVector = new Vector2D(x, y);
                tempVector.Normalize();//normalize the direction vectors
                directions[i] = tempVector;
            }

        }
        /// <summary>
        /// draws the death animation for a tank
        /// </summary>
        /// <param name="e"></param>
        /// <param name="currentFrame"></param>
        public void Draw(PaintEventArgs e, int currentFrame)
        {
            if (currentFrame < startFrame + pDuration)
            {
                running = true;
                e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;

                int locX = random.Next(-30, 30);
                int locY = random.Next(-30, 30);
                r = new Rectangle((int)tank.Loc.GetX() - 10 - locX, (int)tank.Loc.GetY() - 10 - locY, 30, 30);
                r1 = new Rectangle((int)tank.Loc.GetX() - 10 - locX, (int)tank.Loc.GetY() - 10 - locY, 20, 20);

                SolidBrush white = new SolidBrush(Color.Red);
                SolidBrush blue = new SolidBrush(Color.FromArgb(100, Color.Yellow));

                for (int i = 0; i < directions.Length; i++)
                {
                    r.X += (int)directions[i].GetX() * currentFrame;
                    r1.X += (int)directions[i].GetX() * currentFrame;

                    r.Y += (int)directions[i].GetY() * currentFrame;
                    r1.Y += (int)directions[i].GetY() * currentFrame;

                    e.Graphics.FillEllipse(blue, r);
                    e.Graphics.FillEllipse(white, r1);
                }
            }
            else
                running = false;
        }

    }
}
