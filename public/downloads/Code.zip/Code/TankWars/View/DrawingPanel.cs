﻿using Model;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace View
{

    public class DrawingPanel : Panel
    {
        private World theWorld;
        private Tank player;
        private string spritePath;
        private Image background;
        private List<BeamAnimation> beams;
        private List<TankDeathAnimation> explosions;
        private int frame;
        private int frames;
        private Stack<BeamAnimation> toRemove;
        private Stack<TankDeathAnimation> tankRemove;
        private System.Windows.Forms.Timer timer1;
        private int fps;


        public DrawingPanel(World w, Form1 form)
        {
            DoubleBuffered = true;
            theWorld = w;
            spritePath = Directory.GetParent(Directory.GetCurrentDirectory()).Parent.Parent.FullName;//gets the directory path for all the sprites
            background = Image.FromFile(spritePath + "\\Resources\\sprites\\Background.png");//gets the background sprite
            form.FrameArrives += FrameCount;//event handler for counting frames
            beams = new List<BeamAnimation>();
            explosions = new List<TankDeathAnimation>();
            this.BackColor = Color.Black;
            toRemove = new Stack<BeamAnimation>();//played beam animations
            tankRemove = new Stack<TankDeathAnimation>();//played tank animations
            System.Windows.Forms.Timer timer1 = new System.Windows.Forms.Timer();

        }


        // A delegate for DrawObjectWithTransform
        // Methods matching this delegate can draw whatever they want using e  
        public delegate void ObjectDrawer(object o, PaintEventArgs e);
        public delegate void AnimeDrawer(object o, PaintEventArgs e, int i);
        /// <summary>
        /// gets called every frame by form1, increases frame count. used for timing animations
        /// </summary>
        /// <param name="frameCounter"></param>
        public void FrameCount(int frameCounter)
        {
            frame = frameCounter;

        }

        /// <summary>
        /// This method performs a translation and rotation to drawn an object in the world.
        /// </summary>
        /// <param name="e">PaintEventArgs to access the graphics (for drawing)</param>
        /// <param name="o">The object to draw</param>
        /// <param name="worldX">The X coordinate of the object in world space</param>
        /// <param name="worldY">The Y coordinate of the object in world space</param>
        /// <param name="angle">The orientation of the objec, measured in degrees clockwise from "up"</param>
        /// <param name="drawer">The drawer delegate. After the transformation is applied, the delegate is invoked to draw whatever it wants</param>
        private void DrawObjectWithTransform(PaintEventArgs e, object o, double worldX, double worldY, double angle, ObjectDrawer drawer)
        {
            // "push" the current transform
            System.Drawing.Drawing2D.Matrix oldMatrix = e.Graphics.Transform.Clone();

            e.Graphics.TranslateTransform((int)worldX, (int)worldY);
            e.Graphics.RotateTransform((float)angle);
            drawer(o, e);

            // "pop" the transform
            e.Graphics.Transform = oldMatrix;
        }

        //runs once at beginning of drawing
        /// <summary>
        /// Draw Delegate called to draw the walls
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void WallDrawer(object o, PaintEventArgs e)
        {
            Wall w = o as Wall;

            int width = 50;
            int height = 50;

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Image wallSprite = Image.FromFile(spritePath + "\\Resources\\sprites\\WallSprite.png");//getting the sprites for the walls


            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            //draws the full length of the walls from p1 to p2
            if (w.GetDirection())//wall is horizontal
            {
                for (int i = 0; i <= w.GetLength(width); i++)
                {
                    e.Graphics.DrawImage(wallSprite, -(width / 2) + (width * i), -(height / 2), width, height);
                }
            }
            else//wall is vertical
            {
                for (int i = 0; i <= w.GetLength(height); i++)
                {
                    e.Graphics.DrawImage(wallSprite, -(width / 2), -(height / 2) + (height * i), width, height);
                }
            }

        }


        /// <summary>
        /// Acts as a drawing delegate for DrawObjectWithTransform
        /// After performing the necessary transformation (translate/rotate)
        /// DrawObjectWithTransform will invoke this method
        /// </summary>
        /// <param name="o">The object to draw</param>
        /// <param name="e">The PaintEventArgs to access the graphics</param>
        private void PlayerDrawer(object o, PaintEventArgs e)
        {
            Tank p = o as Tank;

            int width = 60;
            int height = 60;

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Image tankSprite = Image.FromFile(spritePath + "\\Resources\\sprites\\" + p.GetTankSprite());

            e.Graphics.DrawImage(tankSprite, -(width / 2), -(height / 2), width, height);
        }

        /// <summary>
        /// Acts as a drawing delegate for DrawObjectWithTransform
        /// After performing the necessary transformation (translate/rotate)
        /// DrawObjectWithTransform will invoke this method
        /// </summary>
        /// <param name="o">The object to draw</param>
        /// <param name="e">The PaintEventArgs to access the graphics</param>
        private void TurretDrawer(object o, PaintEventArgs e)
        {
            Tank p = o as Tank;

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Image turrSprite = Image.FromFile(spritePath + "\\Resources\\sprites\\" + p.GetTurrSprite());

            e.Graphics.DrawImage(turrSprite, -25, -25, 50, 50);
        }

        /// <summary>
        /// Acts as a drawing delegate for DrawObjectWithTransform
        /// After performing the necessary transformation (translate/rotate)
        /// DrawObjectWithTransform will invoke this method
        /// </summary>
        /// <param name="o">The object to draw</param>
        /// <param name="e">The PaintEventArgs to access the graphics</param>
        private void PowerupDrawer(object o, PaintEventArgs e)
        {
            Powerups p = o as Powerups;

            int width = 8;
            int height = 8;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;


            // Circles are drawn starting from the top-left corner.
            // So if we want the circle centered on the powerup's location, we have to offset it
            // by half its size to the left (-width/2) and up (-height/2)
            Rectangle r = new Rectangle(-(width / 2), -(height / 2), width, height);
            Rectangle r1 = new Rectangle(-(width / 2) - 2, -(height / 2) - 2, width + 4, height + 4);
            e.Graphics.FillEllipse(new SolidBrush(Color.Orange), r1);
            e.Graphics.FillEllipse(new SolidBrush(Color.Green), r);


        }

        /// <summary>
        /// Acts as a drawing delegate for DrawObjectWithTransform
        /// After performing the necessary transformation
        /// DrawObjectWithTransform will invoke this method
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void ProjectileDrawer(object o, PaintEventArgs e)
        {
            Projectile p = o as Projectile;

            int size = 30;
            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            Image shotSprite = Image.FromFile(spritePath + "\\Resources\\sprites\\" + p.GetShotSprite());

            e.Graphics.DrawImage(shotSprite, -(size / 2), -(size / 2), size, size);

        }

        /// <summary>
        /// Acts as a drawing delegate for DrawObjectWithTransform
        /// After performing the necessary transformation
        /// DrawObjectWithTransform will invoke this method
        /// </summary>
        /// <param name="o"></param>
        /// <param name="e"></param>
        private void BeamDrawer(object o, PaintEventArgs e)
        {
            Beam b = o as Beam;

            e.Graphics.SmoothingMode = System.Drawing.Drawing2D.SmoothingMode.AntiAlias;
            b.Dir.Normalize();
            e.Graphics.DrawLine(new Pen(new SolidBrush(Color.Red)), 0, 0, (float)b.Dir.GetX() * (2 * theWorld.GetSize()), (float)b.Dir.GetY() * (2 * theWorld.GetSize()));
        }

        /// <summary>
        /// This method is invoked when the DrawingPanel needs to be re-drawn
        /// </summary>
        /// <param name="e"></param>
        protected override void OnPaint(PaintEventArgs e)
        {
            float viewSize = Size.Width;
            int worldSize = theWorld.GetSize();

            //sets play to the center of the  view
            if (theWorld.GetPlayer() != null)
            {
                player = theWorld.GetPlayer();
                double playerX = player.Loc.GetX();
                double playerY = player.Loc.GetY();
                e.Graphics.TranslateTransform((float)(-playerX + (viewSize / 2)), (float)(-playerY + (viewSize / 2)));
            }
            //draws background in world space
            e.Graphics.DrawImage(background, (-worldSize / 2), (-worldSize / 2), worldSize, worldSize);

            //draws walls
            lock (theWorld)
            {
                foreach (Wall wall in theWorld.GetWalls())
                {
                    double x = wall.GetStartpoint().GetX();
                    double y = wall.GetStartpoint().GetY();
                    DrawObjectWithTransform(e, wall, x, y, 0, WallDrawer);
                }
            }


            // Draw the tanks
            lock (theWorld)
            {
                foreach (Tank tank in theWorld.GetTanks().Values)
                {
                    double x = tank.Loc.GetX();
                    double y = tank.Loc.GetY();

                    DrawObjectWithTransform(e, tank, x, y, tank.Ori.ToAngle(), PlayerDrawer);
                    DrawObjectWithTransform(e, tank, x, y, tank.GetTurrDir().ToAngle(), TurretDrawer);
                    e.Graphics.DrawString(tank.Name + ": " + tank.Score.ToString(), new Font("Arial", 10, FontStyle.Bold), new SolidBrush(Color.White), new Point((int)x - 30, (int)y + 30));
                    //draws the ui for all the tanks
                    int healthInc = 20;
                    int healthLength = healthInc * tank.GetHp();
                    Rectangle r = new Rectangle((int)x - 30, (int)y - 50, healthLength, 10);
                    if (healthLength >= 60)
                    {
                        e.Graphics.FillRectangle(new SolidBrush(Color.Green), r);
                    }
                    else if (healthLength >= 40 && healthLength < 60)
                    {
                        e.Graphics.FillRectangle(new SolidBrush(Color.Yellow), r);
                    }
                    else
                    {
                        e.Graphics.FillRectangle(new SolidBrush(Color.Red), r);
                    }
                }
            }

            //draw powerups
            lock (theWorld)
            {
                foreach (Powerups pow in theWorld.GetPowerups().Values)
                {
                    DrawObjectWithTransform(e, pow, pow.Loc.GetX(), pow.Loc.GetY(), 0, PowerupDrawer);
                }
            }
            //draw projectiles
            lock (theWorld)
            {
                foreach (Projectile p in theWorld.GetProjectiles().Values)
                {
                    DrawObjectWithTransform(e, p, p.Loc.GetX(), p.Loc.GetY(), p.Dir.ToAngle(), ProjectileDrawer);
                }
            }

            //keeps track of all the animations that have been played, so they can be deleted later

            lock (theWorld)
            {
                foreach (BeamAnimation b in beams)//loop through all the beams animations that need to be drawn
                {
                    b.Draw(e, frame);
                    if (b.End)
                    {
                        lock (beams)
                        {
                            toRemove.Push(b);
                        }

                    }

                }
            }

            lock (theWorld)
            {
                foreach (TankDeathAnimation t in explosions)//loop through all the tank animations that need to be drawn
                {
                    t.Draw(e, frame);
                    if (t.End)//if the animation is over the put tank on the in the stack to be removed
                    {
                        lock (beams)
                        {
                            tankRemove.Push(t);
                        }
                    }

                }
            }

            if (toRemove.Count >= 10 || tankRemove.Count >= 10)//if either of the animation stack get too big then delete all of them. 10 is arbitrary and only exists to save time from removing small amounts of code
            {
                lock (beams)
                {
                    RemoveAnimation(toRemove, tankRemove);
                }
            }

            base.OnPaint(e);
        }

        /// <summary>
        /// helper method used to remove all the finished animations from animation lists
        /// </summary>
        /// <param name="toRemove"></param>
        /// <param name="tankRemove"></param>
        private void RemoveAnimation(Stack<BeamAnimation> toRemove, Stack<TankDeathAnimation> tankRemove)
        {
            foreach (BeamAnimation beam in toRemove)
            {
                beams.Remove(beam);
            }
            foreach (TankDeathAnimation tank in tankRemove)
            {
                explosions.Remove(tank);
            }
        }

        /// <summary>
        /// creates a new beam animation out of the beam recieved from form and the current frame the animation was created on
        /// </summary>
        /// <param name="newBeam"></param>
        public void NewBeam(Beam newBeam)
        {
            lock (theWorld)
            {
                beams.Add(new BeamAnimation(newBeam, theWorld.GetSize(), frame));
            }
        }

        /// <summary>
        /// creates a new tank death animation to be played by on paint
        /// </summary>
        /// <param name="tank"></param>
        public void RemoveTank(Tank tank)
        {
            lock (theWorld)
            {
                explosions.Add(new TankDeathAnimation(tank, frame, 20));
            }
        }

    }
}
