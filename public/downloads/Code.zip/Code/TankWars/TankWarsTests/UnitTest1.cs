using Microsoft.VisualStudio.TestTools.UnitTesting;
using Model;
using TankWars;

namespace TankWarsTests
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void StartPointTest()
        {
            Vector2D p1 = new Vector2D(-575, -575);
            Vector2D p2 = new Vector2D(-575, 575);
            Wall w = new Wall(1, p1, p2);
            Assert.AreEqual(p1, w.GetStartpoint());
        }

        [TestMethod]
        public void GetDirectionTest()
        {
            Vector2D p1 = new Vector2D(-575, -575);
            Vector2D p2 = new Vector2D(-575, 575);
            Wall w = new Wall(1, p1, p2);
            Assert.IsFalse(w.GetDirection());
        }

        [TestMethod]
        public void GetLengthTest()
        {
            Vector2D p1 = new Vector2D(-575, -575);
            Vector2D p2 = new Vector2D(-575, 575);
            Wall w = new Wall(1, p1, p2);

            Assert.AreEqual(1150, w.GetHeight());
        }

        [TestMethod]
        public void GetIterationsTest()
        {
            Vector2D p1 = new Vector2D(-575, -575);
            Vector2D p2 = new Vector2D(-575, 575);
            Wall w = new Wall(1, p1, p2);

            Assert.AreEqual(23, w.GetLength(50));
        }

        [TestMethod]
        public void TankIDTest()
        {
            Tank t = new Tank(1, "name");
            Assert.AreEqual(1, t.GetID());

        }

        [TestMethod]
        public void ProjectileLocSetGetTest()
        {
            Projectile p = new Projectile(1,1);
            p.Loc = new Vector2D(2, 2);
            Assert.AreEqual(2, p.Loc.GetX());
        }

    }
}
