﻿
namespace SpreadsheetGUI
{
    partial class spreadWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayout = new System.Windows.Forms.TableLayoutPanel();
            this.spreadsheetPanel1 = new SS.SpreadsheetPanel();
            this.menuFileControl = new System.Windows.Forms.TableLayoutPanel();
            this.fileDrop = new System.Windows.Forms.ComboBox();
            this.colorDrop = new System.Windows.Forms.ComboBox();
            this.dataDrop = new System.Windows.Forms.ComboBox();
            this.helpButton = new System.Windows.Forms.Button();
            this.cellInfoLayout = new System.Windows.Forms.TableLayoutPanel();
            this.contentLabel = new System.Windows.Forms.Label();
            this.cellLabel = new System.Windows.Forms.Label();
            this.valLabel = new System.Windows.Forms.Label();
            this.contentText = new System.Windows.Forms.TextBox();
            this.valueText = new System.Windows.Forms.TextBox();
            this.nameText = new System.Windows.Forms.TextBox();
            this.tableLayout.SuspendLayout();
            this.menuFileControl.SuspendLayout();
            this.cellInfoLayout.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayout
            // 
            this.tableLayout.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Single;
            this.tableLayout.ColumnCount = 1;
            this.tableLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayout.Controls.Add(this.spreadsheetPanel1, 0, 2);
            this.tableLayout.Controls.Add(this.menuFileControl, 0, 0);
            this.tableLayout.Controls.Add(this.cellInfoLayout, 0, 1);
            this.tableLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayout.Location = new System.Drawing.Point(0, 0);
            this.tableLayout.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.tableLayout.Name = "tableLayout";
            this.tableLayout.RowCount = 2;
            this.tableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 40F));
            this.tableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 60F));
            this.tableLayout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.tableLayout.Size = new System.Drawing.Size(1005, 654);
            this.tableLayout.TabIndex = 0;
            // 
            // spreadsheetPanel1
            // 
            this.spreadsheetPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.spreadsheetPanel1.Location = new System.Drawing.Point(4, 105);
            this.spreadsheetPanel1.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.spreadsheetPanel1.Name = "spreadsheetPanel1";
            this.spreadsheetPanel1.Size = new System.Drawing.Size(997, 586);
            this.spreadsheetPanel1.TabIndex = 0;
            this.spreadsheetPanel1.TabStop = false;
            // 
            // menuFileControl
            // 
            this.menuFileControl.AutoSize = true;
            this.menuFileControl.ColumnCount = 4;
            this.menuFileControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.menuFileControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.menuFileControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.menuFileControl.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25F));
            this.menuFileControl.Controls.Add(this.fileDrop, 0, 0);
            this.menuFileControl.Controls.Add(this.colorDrop, 1, 0);
            this.menuFileControl.Controls.Add(this.dataDrop, 2, 0);
            this.menuFileControl.Controls.Add(this.helpButton, 3, 0);
            this.menuFileControl.Dock = System.Windows.Forms.DockStyle.Fill;
            this.menuFileControl.Location = new System.Drawing.Point(4, 3);
            this.menuFileControl.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.menuFileControl.Name = "menuFileControl";
            this.menuFileControl.RowCount = 1;
            this.menuFileControl.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.menuFileControl.Size = new System.Drawing.Size(997, 36);
            this.menuFileControl.TabIndex = 1;
            // 
            // fileDrop
            // 
            this.fileDrop.BackColor = System.Drawing.SystemColors.Menu;
            this.fileDrop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.fileDrop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.fileDrop.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.fileDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.fileDrop.FormattingEnabled = true;
            this.fileDrop.Items.AddRange(new object[] {
            "File",
            "New Sheet",
            "New Window",
            "Save",
            "Save as",
            "Open",
            "Close"});
            this.fileDrop.Location = new System.Drawing.Point(3, 2);
            this.fileDrop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.fileDrop.Name = "fileDrop";
            this.fileDrop.Size = new System.Drawing.Size(243, 28);
            this.fileDrop.TabIndex = 4;
            this.fileDrop.TabStop = false;
            this.fileDrop.SelectedIndexChanged += new System.EventHandler(this.fileDrop_SelectedIndexChanged);
            // 
            // colorDrop
            // 
            this.colorDrop.BackColor = System.Drawing.SystemColors.Menu;
            this.colorDrop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.colorDrop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.colorDrop.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.colorDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.colorDrop.FormattingEnabled = true;
            this.colorDrop.Items.AddRange(new object[] {
            "Appearance",
            "Pink",
            "Blue",
            "Red",
            "Green"});
            this.colorDrop.Location = new System.Drawing.Point(252, 2);
            this.colorDrop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.colorDrop.Name = "colorDrop";
            this.colorDrop.Size = new System.Drawing.Size(243, 28);
            this.colorDrop.TabIndex = 6;
            this.colorDrop.TabStop = false;
            this.colorDrop.SelectedIndexChanged += new System.EventHandler(this.colorDrop_SelectedIndexChanged);
            // 
            // dataDrop
            // 
            this.dataDrop.BackColor = System.Drawing.SystemColors.Menu;
            this.dataDrop.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dataDrop.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.dataDrop.FlatStyle = System.Windows.Forms.FlatStyle.System;
            this.dataDrop.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataDrop.FormattingEnabled = true;
            this.dataDrop.Items.AddRange(new object[] {
            "Data",
            "Find Cell",
            "Sort Cells in a Column (greatest to least)",
            "Sort Cells in a Column (least to greatest)",
            "Sort Cells in a Row (greatest to least)",
            "Sort Cells in a Row (least to greatest)"});
            this.dataDrop.Location = new System.Drawing.Point(501, 2);
            this.dataDrop.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.dataDrop.Name = "dataDrop";
            this.dataDrop.Size = new System.Drawing.Size(243, 28);
            this.dataDrop.TabIndex = 5;
            this.dataDrop.TabStop = false;
            this.dataDrop.SelectedIndexChanged += new System.EventHandler(this.dataDrop_SelectedIndexChanged);
            // 
            // helpButton
            // 
            this.helpButton.AutoSize = true;
            this.helpButton.Dock = System.Windows.Forms.DockStyle.Fill;
            this.helpButton.Location = new System.Drawing.Point(750, 2);
            this.helpButton.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.helpButton.Name = "helpButton";
            this.helpButton.Size = new System.Drawing.Size(244, 30);
            this.helpButton.TabIndex = 3;
            this.helpButton.TabStop = false;
            this.helpButton.Text = "Help Menu";
            this.helpButton.UseVisualStyleBackColor = true;
            this.helpButton.Click += new System.EventHandler(this.helpButton_Click);
            // 
            // cellInfoLayout
            // 
            this.cellInfoLayout.ColumnCount = 3;
            this.cellInfoLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.cellInfoLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.cellInfoLayout.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 33.33333F));
            this.cellInfoLayout.Controls.Add(this.contentLabel, 1, 0);
            this.cellInfoLayout.Controls.Add(this.cellLabel, 0, 0);
            this.cellInfoLayout.Controls.Add(this.valLabel, 2, 0);
            this.cellInfoLayout.Controls.Add(this.contentText, 1, 1);
            this.cellInfoLayout.Controls.Add(this.valueText, 2, 1);
            this.cellInfoLayout.Controls.Add(this.nameText, 0, 1);
            this.cellInfoLayout.Dock = System.Windows.Forms.DockStyle.Fill;
            this.cellInfoLayout.Location = new System.Drawing.Point(5, 46);
            this.cellInfoLayout.Margin = new System.Windows.Forms.Padding(4);
            this.cellInfoLayout.Name = "cellInfoLayout";
            this.cellInfoLayout.RowCount = 2;
            this.cellInfoLayout.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.cellInfoLayout.RowStyles.Add(new System.Windows.Forms.RowStyle());
            this.cellInfoLayout.Size = new System.Drawing.Size(995, 52);
            this.cellInfoLayout.TabIndex = 2;
            // 
            // contentLabel
            // 
            this.contentLabel.AutoSize = true;
            this.contentLabel.Location = new System.Drawing.Point(334, 0);
            this.contentLabel.Name = "contentLabel";
            this.contentLabel.Size = new System.Drawing.Size(57, 17);
            this.contentLabel.TabIndex = 8;
            this.contentLabel.Text = "Content";
            // 
            // cellLabel
            // 
            this.cellLabel.AutoSize = true;
            this.cellLabel.Location = new System.Drawing.Point(3, 0);
            this.cellLabel.Name = "cellLabel";
            this.cellLabel.Size = new System.Drawing.Size(45, 17);
            this.cellLabel.TabIndex = 7;
            this.cellLabel.Text = "Name";
            // 
            // valLabel
            // 
            this.valLabel.AutoSize = true;
            this.valLabel.Location = new System.Drawing.Point(665, 0);
            this.valLabel.Name = "valLabel";
            this.valLabel.Size = new System.Drawing.Size(44, 17);
            this.valLabel.TabIndex = 9;
            this.valLabel.Text = "Value";
            // 
            // contentText
            // 
            this.contentText.BackColor = System.Drawing.SystemColors.Window;
            this.contentText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.contentText.Location = new System.Drawing.Point(334, 22);
            this.contentText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.contentText.Name = "contentText";
            this.contentText.Size = new System.Drawing.Size(325, 22);
            this.contentText.TabIndex = 2;
            this.contentText.TabStop = false;
            this.contentText.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.CheckEnterKeyPress);
            // 
            // valueText
            // 
            this.valueText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.valueText.Location = new System.Drawing.Point(665, 22);
            this.valueText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.valueText.Name = "valueText";
            this.valueText.ReadOnly = true;
            this.valueText.Size = new System.Drawing.Size(327, 22);
            this.valueText.TabIndex = 1;
            this.valueText.TabStop = false;
            // 
            // nameText
            // 
            this.nameText.Dock = System.Windows.Forms.DockStyle.Fill;
            this.nameText.Location = new System.Drawing.Point(3, 22);
            this.nameText.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.nameText.Name = "nameText";
            this.nameText.ReadOnly = true;
            this.nameText.Size = new System.Drawing.Size(325, 22);
            this.nameText.TabIndex = 0;
            this.nameText.TabStop = false;
            // 
            // spreadWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1005, 654);
            this.Controls.Add(this.tableLayout);
            this.Margin = new System.Windows.Forms.Padding(3, 2, 3, 2);
            this.Name = "spreadWindow";
            this.Text = "Spreadsheet Editor";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.spreadWindow_FormClosing);
            this.tableLayout.ResumeLayout(false);
            this.tableLayout.PerformLayout();
            this.menuFileControl.ResumeLayout(false);
            this.menuFileControl.PerformLayout();
            this.cellInfoLayout.ResumeLayout(false);
            this.cellInfoLayout.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayout;
        private System.Windows.Forms.TableLayoutPanel menuFileControl;
        private System.Windows.Forms.ComboBox colorDrop;
        private System.Windows.Forms.ComboBox dataDrop;
        private System.Windows.Forms.ComboBox fileDrop;
        private System.Windows.Forms.Button helpButton;
        private System.Windows.Forms.TableLayoutPanel cellInfoLayout;
        private System.Windows.Forms.TextBox contentText;
        private System.Windows.Forms.TextBox valueText;
        private System.Windows.Forms.TextBox nameText;
        private System.Windows.Forms.Label contentLabel;
        private System.Windows.Forms.Label valLabel;
        private System.Windows.Forms.Label cellLabel;
        private SS.SpreadsheetPanel spreadsheetPanel1;
    }
}

