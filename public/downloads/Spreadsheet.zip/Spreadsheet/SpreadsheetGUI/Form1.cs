﻿
using Microsoft.VisualBasic;
using SpreadsheetUtilities;
using SS;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Media;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SpreadsheetGUI
{
    /// <summary>
    /// Authors: Maya Tyner and Ryan Vreeke
    /// </summary>
    public partial class spreadWindow : Form
    {
        private Spreadsheet spreadsheet;
        private SpreadsheetPanel ss;
        private string selected;
        private int col, row;
        private string filePath;
        private string name;

        //should boot an empty spreadsheet
        /// <summary>
        /// Boots an empty spreadsheet and initializesComponents
        /// </summary>
        public spreadWindow()
        {
            InitializeComponent();
            KeyPreview = true;

            spreadsheet = new Spreadsheet(s => true, s => s.ToUpper(), "ps6");
            selected = "A1";
            nameText.Text = selected;

            ss = spreadsheetPanel1;
            spreadsheetPanel1.SelectionChanged += DisplaySelection;
            ss.SetSelection(0, 0);

            PinkMode();
            contentText.Focus();
            contentText.Select();

            fileDrop.SelectedIndex = 0;
            colorDrop.SelectedIndex = 0;
            dataDrop.SelectedIndex = 0;
        }

        /// <summary>
        /// Shows what the selected cell is (string name at this time)
        /// </summary>
        /// <param name="ss"></param>
        private void DisplaySelection(SpreadsheetPanel ss)
        {
            //gets selected spot
            ss.GetSelection(out col, out row);
            ss.SetSelection(col, row);

            //turns row and column into cell names
            //ASCII characters 65 to 90
            name = ((char)(col + 65)).ToString() + (row + 1).ToString();

            contentText.Text = spreadsheet.GetCellContents(name).ToString();
            valueText.Text = spreadsheet.GetCellValue(name).ToString();
            nameText.Text = name;

            selected = name;

        }

        /// <summary>
        /// closes the program when called
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void closeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
        /// <summary>
        /// opens a user entrybox to warn the user that they are doing something that will destroy unsaved data
        /// </summary>
        private void validateUserEntry()
        {
            // Checks the value of the text.
            // Initializes the variables to pass to the MessageBox.Show method.
            string message = "You didn't save your current spreadsheet. would you like to save any unsaved data?";
            string caption = "Unsaved Data";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;

            // Displays the MessageBox.
            result = MessageBox.Show(message, caption, buttons);
            if (result == System.Windows.Forms.DialogResult.Yes)
                SaveFile();
        }
        /// <summary>
        /// Event handler called when a file needs to be saved. if the current spreadsheet already has a filepath associated with it then it will save directly to that file path if it doesn't have a file path
        /// then a save file dialog window will open up and get the users desired file path, then save the spreadsheet and set that filepath to the default for the current spreadsheet.
        /// </summary>
        private void SaveFile()
        {
            if (GetPath())//gets the user designated path and returns if that path is valid
                spreadsheet.Save(filePath);//saves the spreadsheet using the filepath
        }
        /// <summary>
        /// manages the filepath of the spreadsheet. if there isn't a filepath already assigned then make a new one by opening a save file dialog window
        /// </summary>
        /// <returns>returns true if DialogResult is OK</returns>
        private bool GetPath()
        {
            SaveFileDialog saveFileDialog1 = new SaveFileDialog();
            if (filePath is null || filePath == "")//check if there is already a filepath associated with this file
            {
                // Displays a SaveFileDialog so the user can save the Image
                // assigned to save Button.
                saveFileDialog1.Filter = "spreadsheet files (*.sprd)|*.sprd| All Files (*.*)|*.*";
                saveFileDialog1.Title = "Save a Spreadsheet File";
                saveFileDialog1.FileName = "spreadsheet";
                saveFileDialog1.DefaultExt = "spreadsheet files (*.sprd)|*.sprd";
                DialogResult result = saveFileDialog1.ShowDialog();
                if (result == DialogResult.OK)//checks if ok or enter is pressed 
                {
                    filePath = (saveFileDialog1.FileName);//saves current spreadsheet to filename
                    this.Text = saveFileDialog1.FileName;
                    return true;//returns true because saving will not cause any issues
                }
            }
            else
            {
                return true;
            }

            return false;//returns false because saving using the provided file path wont work 
        }
        /// <summary>
        /// Action handling method for new selection option. will create a new spreadsheet and clear the contents of the old one
        /// </summary>
        private void NewFile()
        {
            if (spreadsheet.Changed)//if the spreadsheet has unsaved changes 
                validateUserEntry();//open a warning box to ask if the user will save the changes before making a new spreadsheet

            ClearSpreadsheet();//clear the old spreadsheets cells and content box
            this.Text = "new spreadsheet";//sets the title of the program to new spreadsheet to inform the user that they are working on a new spreadsheet
            spreadsheet = new Spreadsheet(s => true, s => s.ToUpper(), "ps6");
        }

        /// <summary>
        /// Creates a completely new spreadsheet window
        /// </summary>
        private void NewWind()
        {
            SpreadApplicationContext.getAppContext().RunForm(new spreadWindow());
        }

        /// <summary>
        /// clears the spreadsheet cells, content, and value 
        /// </summary>
        private void ClearSpreadsheet()
        {
            ss.Clear();
            contentText.Clear();
            valueText.Clear();
        }
        /// <summary>
        /// Opens file using OpenFileDialog window.
        /// </summary>
        private void OpenFile()
        {
            OpenFileDialog openFileDialog1 = new OpenFileDialog();
            openFileDialog1.Filter = "spreadsheet files (*.sprd)|*.sprd| All Files (*.*)|*.*";//allows for two options when looking for file. either only .sprd extensions or all files
            openFileDialog1.DefaultExt = "spreadsheet files (*.sprd)|*.sprd";
            DialogResult result = openFileDialog1.ShowDialog(); // Show the dialog.
            if (result == DialogResult.OK) // Test result.
            {
                filePath = openFileDialog1.FileName;//gets the file path of the selected file
                this.Text = filePath.Split('\\').Last();//sets the title of the program to the name of the opened spreadsheet. removes every thing in the path name except the name of the spreadsheet
                try
                {
                    spreadsheet = new Spreadsheet(filePath, s => true, s => s.ToUpper(), "ps6");//makes a new spreadsheet using the specified filepath
                }
                catch (SpreadsheetReadWriteException)
                {
                    playSimpleSound("Oh_No_Our_Table_Its_Broken_Original_Video.wav");//playes an error sound to inform the user that something went wrong
                    MessageBox.Show("Couldn't read provided file. Please select a file ending with .sprd And verify the version of the spreadsheet is correct");
                }

                ClearSpreadsheet();
                foreach (string cellName in spreadsheet.GetNamesOfAllNonemptyCells())//fills in all the cells 
                    ss.SetValue(((int)cellName[0]) - 65, int.Parse(cellName[1] + "") - 1, spreadsheet.GetCellValue(cellName).ToString());
            }
        }
        /// <summary>
        /// plays simple sounds that are in the sound effect file.
        /// </summary>
        /// <param name="soundName"></param>
        private void playSimpleSound(string soundName)
        {
            string path = Path.Combine(Environment.CurrentDirectory, @"SoundEffects\", soundName);// gets the path of the sound
            try
            {
                SoundPlayer simpleSound = new SoundPlayer(path);
                simpleSound.Play();//plays the sound on a new thread
            }
            catch (Exception)
            {
                //sound wasn't found so do nothing. just doing this to make sure the program doesn't crash if sound files aren't loaded correctly
            }
        }

        /// <summary>
        /// Event handler for File drop down menu. When file drop down is selected and an item is selected, activates a handler.
        /// Items include opening, closing, saving, save as, and creating a new spreadsheet.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void fileDrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (fileDrop.SelectedItem)
            {
                case "Open"://open file
                    OpenFile();
                    break;
                case "New Sheet"://new sheet on the same window
                    NewFile();
                    break;
                case "New Window":// new spreadsheet on a new window
                    NewWind();
                    break;
                case "Close"://close program
                    this.Close();
                    break;
                case "Save"://save spreadsheet
                    SaveFile();
                    break;
                case "Save as"://save spreadsheet in a new location seperate from where it was saved before
                    filePath = null;
                    SaveFile();
                    break;
            }
            fileDrop.SelectedIndex = 0;//setting the file dropdown back to index 0
        }

        /// <summary>
        /// Help button handler. Creates an instance of the PopForm class which explains how to use the spreadsheet editor.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void helpButton_Click(object sender, EventArgs e)
        {
            PopForm helpMenu = new PopForm();//making a popform window that tells the user how functions work 
            helpMenu.Show(this);
        }
        /// <summary>
        /// Enter key handler. Information typed into the content textbox is saved to the cell in the spreadsheet and is then displayed on the grid.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void CheckEnterKeyPress(object sender, System.Windows.Forms.KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Return)//checks if the key pressed char is enter
            {
                playSimpleSound("EnterSFX.wav");//plays sound effect to inform user that the content was added to the cell
                try
                {
                    spreadsheet.SetContentsOfCell(selected, contentText.Text);//sets the cells contents to contentText
                    valueText.Text = spreadsheet.GetCellValue(selected).ToString();

                    foreach (string cellname in spreadsheet.GetNamesOfAllNonemptyCells())
                    {
                        ss.SetValue(((int)cellname[0]) - 65, int.Parse(cellname[1] + "") - 1, spreadsheet.GetCellValue(cellname).ToString());
                    }
                }
                catch (FormulaFormatException)
                {
                    playSimpleSound("Oh_No_Our_Table_Its_Broken_Original_Video.wav");//plays an error sound to inform the user that the formula entered isn't valid
                    MessageBox.Show("Invalid formula entered. Make sure all characters are valid and operators are used appropriately");
                }
                e.Handled = true; //handles e so it doesn't doing somthing later
            }
        }
        /// <summary>
        /// Gets what selection was made in the color drop down box and updates the appearance of the user interface.
        /// Options are pink, blue, red, and green.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void colorDrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            switch (colorDrop.SelectedItem)//gets the selected item 
            {
                case "Pink"://color themes ping, blue, red, and green
                    PinkMode();
                    break;
                case "Blue":
                    BlueMode();
                    break;
                case "Red":
                    RedMode();
                    break;
                case "Green":
                    GreenMode();
                    break;
            }
            colorDrop.SelectedIndex = 0;//set color drop box back to first index 
        }
        /// <summary>
        /// Pink theme method. this method sets the colors of the program to a pink theme
        /// </summary>
        private void PinkMode()
        {
            this.BackColor = Color.Ivory;
            ss.BackColor = Color.PeachPuff;
        }
        /// <summary>
        /// Blue theme action method.
        /// </summary>
        private void BlueMode()
        {
            this.BackColor = Color.Aqua;
            ss.BackColor = Color.LightCyan;
        }

        /// <summary>
        /// Red Theme action method
        /// </summary>
        private void RedMode()
        {
            this.BackColor = Color.Salmon;
            ss.BackColor = Color.LightCoral;
        }

        /// <summary>
        /// Green theme action method 
        /// </summary>
        private void GreenMode()
        {
            this.BackColor = Color.LightGreen;
            ss.BackColor = Color.PaleGreen;
        }

        /// <summary>
        /// Action handler for the data drop down box.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void dataDrop_SelectedIndexChanged(object sender, EventArgs e)
        {
            //gets the selected item and calls the corresponding method
            switch (dataDrop.SelectedItem)
            {
                case "Find Cell":
                    FindCell();//will find all cells that contains specified content
                    break;
                case "Sort Cells in a Row (least to greatest)":
                    SortRowLToG();
                    break;
                case "Sort Cells in a Column (least to greatest)":
                    SortColumnLToG();
                    break;
                case "Sort Cells in a Row (greatest to least)":
                    SortRowGToL();
                    break;
                case "Sort Cells in a Column (greatest to least)":
                    SortColumnGToL();
                    break;
            }
            dataDrop.SelectedIndex = 0;
        }
        /// <summary>
        /// Opens a interaction input box and finds all the cells that contain that user input
        /// </summary>
        private void FindCell()
        {
            string allNames = "";//creates and empty string that will hold the names of all cells that contain the users input key
            string userInput = Interaction.InputBox("What are you looking for?", "", "");//opens a messagebox that will ask for the user input 
            foreach (string name in spreadsheet.GetNamesOfAllNonemptyCells())
            {
                if (spreadsheet.GetCellContents(name).ToString().Contains(userInput))
                {
                    allNames += name + ", ";//appends the name of the cell the string of allNames
                }
            }
            MessageBox.Show("Results found in: " + allNames);//shows the user all the cells containing the key
        }
        /// <summary>
        /// sorts the cells in a row from least to greatest based on their values
        /// </summary>
        private void SortRowLToG()
        {
            string pattern = (row + 1) + "$";//regexs pattern to determin if the cell is in this row
            List<string> allNames = new List<string>();// all cells that are sorted
            List<Tuple<double, object>> values = new List<Tuple<double, object>>();//list of values of the cells 
            try
            {
                foreach (string names in spreadsheet.GetNamesOfAllNonemptyCells())//loop over all nonempty cells
                {
                    if (Regex.IsMatch(names, pattern))//checks if the cell in part of this row
                    {
                        allNames.Add(names);//adds current cell to names list 
                        values.Add(new Tuple<double, object>(Double.Parse(spreadsheet.GetCellValue(names).ToString()), spreadsheet.GetCellContents(names)));//adds current cells value to value list
                    }
                }
                allNames.Sort();//sorts the cells 
                values.Sort((x, y) => x.Item1.CompareTo(y.Item1));//sorts the values
                for (int i = 0; i < allNames.Count; i++)//loops over all changed cells and cets the gui to desplay that new order
                {
                    spreadsheet.SetContentsOfCell(allNames[i], values[i].Item2.ToString());
                    col = ((int)allNames[i][0]) - 65;
                    ss.SetSelection(col, row);
                    ss.SetValue(col, row, values[i].Item2.ToString());
                    DisplaySelection(ss);
                }
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("Unable to sort (invalid values)");//tells the user that the cell couldn't be sorted 
            }
            catch (FormatException)
            {
                MessageBox.Show("Undable to sort (invalid Values)");
            }
        }

        /// <summary>
        /// Sorts the row from Greatest to Least, but only for numbers, will throw an exception if you try to sort strings
        /// </summary>
        private void SortRowGToL()
        {
            string pattern = (row + 1) + "$";
            List<string> allNames = new List<string>();
            List<Tuple<double, object>> values = new List<Tuple<double, object>>();
            try
            {
                foreach (string names in spreadsheet.GetNamesOfAllNonemptyCells())
                {
                    if (Regex.IsMatch(names, pattern))
                    {
                        allNames.Add(names);
                        values.Add(new Tuple<double, object>(Double.Parse(spreadsheet.GetCellValue(names).ToString()), spreadsheet.GetCellContents(names)));
                    }

                }
                allNames.Sort();
                values.Sort((x, y) => y.Item1.CompareTo(x.Item1));
                for (int i = 0; i < allNames.Count; i++)
                {
                    spreadsheet.SetContentsOfCell(allNames[i], values[i].Item2.ToString());
                    col = ((int)allNames[i][0]) - 65;
                    ss.SetSelection(col, row);
                    ss.SetValue(col, row, values[i].Item2.ToString());
                    DisplaySelection(ss);
                }
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("Unable to sort (invalid values)");
            }
            catch (FormatException)
            {
                MessageBox.Show("Undable to sort (invalid Values)");
            }
        }
        /// <summary>
        /// sorts cells in a selected column from least to greatest, based on cell values. doesn't work with strings, only with numbers
        /// </summary>
        private void SortColumnLToG()
        {
            string pattern = (char)(col + 65) + "";
            List<string> allNames = new List<string>();
            List<Tuple<double, object>> values = new List<Tuple<double, object>>();
            try
            {
                foreach (string names in spreadsheet.GetNamesOfAllNonemptyCells())
                {
                    if (Regex.IsMatch(names, pattern))
                    {
                        allNames.Add(names);
                        values.Add(new Tuple<double, object>(Double.Parse(spreadsheet.GetCellValue(names).ToString()), spreadsheet.GetCellContents(names)));//FormatException
                    }
                }
                allNames.Sort();
                values.Sort((x, y) => x.Item1.CompareTo(y.Item1));
                for (int i = 0; i < allNames.Count; i++)
                {
                    spreadsheet.SetContentsOfCell(allNames[i], values[i].Item2.ToString());
                    row = int.Parse(allNames[i][1] + "") - 1;
                    ss.SetSelection(col, row);
                    ss.SetValue(col, row, values[i].Item2.ToString());
                    DisplaySelection(ss);
                }
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("Unable to sort (invalid values)");
            }
            catch (FormatException)
            {
                MessageBox.Show("Undable to sort (invalid Values)");
            }
        }

        /// <summary>
        /// sorts a column from greatest to least
        /// </summary>
        private void SortColumnGToL()
        {
            string pattern = (char)(col + 65) + "";
            List<string> allNames = new List<string>();
            List<Tuple<double, object>> values = new List<Tuple<double, object>>();
            try
            {
                foreach (string names in spreadsheet.GetNamesOfAllNonemptyCells())
                {
                    if (Regex.IsMatch(names, pattern))
                    {
                        allNames.Add(names);
                        values.Add(new Tuple<double, object>(Double.Parse(spreadsheet.GetCellValue(names).ToString()), spreadsheet.GetCellContents(names)));
                    }
                }
                allNames.Sort();
                values.Sort((x, y) => y.Item1.CompareTo(x.Item1));
                for (int i = 0; i < allNames.Count; i++)
                {
                    spreadsheet.SetContentsOfCell(allNames[i], values[i].Item2.ToString());
                    row = int.Parse(allNames[i][1] + "") - 1;
                    ss.SetSelection(col, row);
                    ss.SetValue(col, row, values[i].Item2.ToString());
                    DisplaySelection(ss);
                }
            }
            catch (InvalidOperationException)
            {
                MessageBox.Show("Unable to sort (invalid values)");
            }
            catch (FormatException)
            {
                MessageBox.Show("Undable to sort (invalid Values)");
            }
        }
        /// <summary>
        /// This will handle the event of hitting the close button. making it so attempting to close the window will open up form asking the user to save unsave data or not
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void spreadWindow_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (spreadsheet.Changed)
                validateUserEntry();
        }

        /// <summary>
        /// Pressing of a key is detected and handled in Windows Form but events dont fire when arrow keys are pressed, so ProcessCmdKey is getting overriddent to detect and handle key events. In this case it is
        /// changing which cell is selected in the spreadsheet
        /// </summary>
        /// <param name="msg"></param>
        /// <param name="keyData"></param>
        /// <returns></returns>
        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            //gets what key was pressed and changes cell selection to reflect what that key does.
            //arrow keys change selection based on direction. tab key changes col selection
            switch (keyData)
            {
                case Keys.Down:
                    if (row < 98)//if the current cell is in the row range the increment selected row by 1
                        row++;
                    ss.SetSelection(col, row);//set selected to new row and col
                    DisplaySelection(ss);//display selection
                    break;
                case Keys.Right:
                    if (col < 25)
                        col++;
                    ss.SetSelection(col, row);
                    DisplaySelection(ss);
                    break;
                case Keys.Up:
                    if (row > 0)
                        row--;
                    ss.SetSelection(col, row);
                    DisplaySelection(ss);
                    break;
                case Keys.Left:
                    if (col > 0)
                        col--;
                    ss.SetSelection(col, row);
                    DisplaySelection(ss);
                    break;
                case Keys.Tab:
                    if (col < 25)
                        col++;
                    ss.SetSelection(col, row);
                    DisplaySelection(ss);
                    break;
            }

            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}