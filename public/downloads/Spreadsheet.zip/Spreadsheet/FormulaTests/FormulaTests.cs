using Microsoft.VisualStudio.TestTools.UnitTesting;
using SpreadsheetUtilities;
using System.Collections.Generic;
using System;

namespace FormulaTests
{
    [TestClass]
    public class FormulaTests
    {

        [TestMethod(), Timeout(5000)]
        [TestCategory("1")]
        public void FilledContructorTest()
        {
            Formula f = new Formula("(5+2)*3");
        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("2")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void EmptyFormulaConstructTest()
        {
            Formula f = new Formula("");
        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("4")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void LastTokenIsInvalidTest()
        {
            Formula f = new Formula("(4+2) +");
        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("5")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void SimpleConstructorTest()
        {
            Formula f = new Formula("(4+2) +");

        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("5")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void UnexpectedTokenAfterParenthesesTest()
        {
            Formula f = new Formula("(*4+2)");

        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("6")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void TooManyParenthesisTest()
        {
            Formula f = new Formula("(((4+2)");

        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("6")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void TokenFollowingADigitVarOrParenthesesTest()
        {
            Formula f = new Formula("4 4");

        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("6")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void TooManyRightParenthesisTest()
        {
            Formula f = new Formula("(2)))");

        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("6")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void FirstTokenIsNotValid()
        {
            Formula f = new Formula(")(4+2)");

        }


        [TestMethod(), Timeout(5000)]
        [TestCategory("7")]
        [ExpectedException(typeof(FormulaFormatException))]
        public void InvalidTokensInFormulaTest()
        {
            Formula f = new Formula("(4+2)/5 * 6 + 2e10 * (#@%)");

        }

        [TestMethod(), Timeout(5000)]
        [ExpectedException(typeof(FormulaFormatException))]
        public void InvalidNormalizedVarTest()
        {
            Formula f = new Formula("A2", s=> "*2", s => true);
        }


        [TestMethod(), Timeout(5000)]
        [TestCategory("7")]

        public void GetVariablesTest()
        {
            Formula f = new Formula("(4+A4) - A3 + _2", s => s.ToUpper(), s => true);
            IEnumerator<string> e1 = f.GetVariables().GetEnumerator();
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("_2", e1.Current);
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("A3", e1.Current);
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("A4", e1.Current);
            Assert.IsFalse(e1.MoveNext());
            f = new Formula("x+y*z", s => s.ToUpper(), s => true);
            e1 = f.GetVariables().GetEnumerator();
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("Z", e1.Current);
            Assert.IsTrue(e1.MoveNext());
            Assert.IsTrue(e1.MoveNext());
        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("7")]
        public void ToStringTest()
        {
            Formula f = new Formula("(a4 + 4) / (5+f2)", s => s.ToUpper(), s => true);
            Assert.AreNotEqual("(a4 + 4) / (5+f2)", f.ToString());
            Assert.AreEqual("(A4+4)/(5+F2)", f.ToString());
        }

        [TestMethod(), Timeout(5000)]
        [ExpectedException(typeof(FormulaFormatException))]
        public void IsValidTest()
        {
            Formula f = new Formula("x+y*z", s => s.ToUpper(), s => false);

        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("7")]
        public void FormulaEqualsTest()
        {
            Formula f1 = new Formula("x1+y2", s => s.ToUpper(), s => true);
            Formula f2 = new Formula("X1 + Y2", s => s.ToUpper(), s => true);
            Formula f3 = new Formula("(X1 + Y2) / 5", s => s.ToUpper(), s => true);
            Formula f4 = new Formula("(X1 + Y2) / 5", s => s.ToUpper(), s => true);
            Assert.IsTrue(f1.Equals(f2));
            Assert.IsTrue(f3.Equals(f4));
            Assert.IsFalse(f1.Equals(f4));
            Formula f5 = new Formula("x1+y2");
            Formula f6 = new Formula("X1 + Y2");
            Assert.IsFalse(f5 == f6);
            f5 = new Formula("2.0 + y2");
            f6 = new Formula("2.000 + y2");
            Assert.IsTrue(f5 == f6);
            Assert.IsFalse(f5 != f6);
            f6 = new Formula("2.1 + y2");
            Assert.IsTrue(f5 != f6);
            f6 = null;
            Assert.IsFalse(f5 == f6);
            Assert.IsTrue(f5 != f6);
            f5 = null;
            Assert.IsTrue(f5 == f6);
            Assert.IsFalse(f5 != f6);
            f6 = new Formula("4+5");
            Assert.IsFalse(f5 == f6);
            Assert.IsTrue(f5 != f6);
        }

        [TestMethod(), Timeout(5000)]
        [TestCategory("7")]
        public void GetHashCodeTest()
        {
            Formula f1 = new Formula("x1+y2", s => s.ToUpper(), s => true);
            Formula f2 = new Formula("X1 + Y2", s => s.ToUpper(), s => true);

            Assert.IsTrue(f1 == f2);
            Assert.IsTrue(f2 == f1);
            Assert.AreEqual(f2.GetHashCode(), f1.GetHashCode());

        }

        [TestMethod(), Timeout(5000)]
        public void SingleNumberTest()
        {
            Formula f = new Formula("5");
            Assert.AreEqual(5f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void SimpleAdditionTest()
        {
            Formula f = new Formula("5 + 2 + 2 + 5");
            Assert.AreEqual(14f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void SingleVariableTest()
        {
            Formula f = new Formula("X4");
            Assert.AreEqual(15f, (double)f.Evaluate(s => 15), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void AdditionTest()
        {
            Formula f = new Formula("4 + 4");
            Assert.AreEqual(8.0f, (double)f.Evaluate(s => 0), 1e-4);
        }

        [TestMethod(), Timeout(5000)]
        public void SubtractionTest()
        {
            Formula f = new Formula("4 - 4");
            Assert.AreEqual(0f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void MultiplcationTest()
        {
            Formula f = new Formula("4 * 4");
            Assert.AreEqual(16f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void DivisionTest()
        {
            Formula f = new Formula("4 / 4");
            Assert.AreEqual(1.0f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void VarMathTest()
        {
            Formula f = new Formula("(X4 + 2) / 3");
            Assert.AreEqual(1, (double)f.Evaluate(s => 1), 1e-9);
            f = new Formula("(X4 + x3) / 3");
            Assert.AreEqual(2 / 3f, (double)f.Evaluate(s => 1), 1e-4);
        }

        [TestMethod(), Timeout(5000)]
        public void VariableNotFoundTest()
        {
            Formula f = new Formula("(X4 + 2) / 3");

            FormulaError ef = (FormulaError)f.Evaluate(s => { throw new ArgumentException(); });
            Assert.AreEqual("That Variable doesn't have a assigned value", ef.Reason);

        }

        [TestMethod(), Timeout(5000)]
        public void DividByZeroTest()
        {
            Formula f = new Formula("2 / (X4 - 2)");

            FormulaError ef = (FormulaError)f.Evaluate(s => 2);
            Assert.AreEqual("divided by zero", ef.Reason);
        }

        [TestMethod(), Timeout(5000)]
        public void VariableDividByZeroTest()
        {
            Formula f = new Formula("(X4 + 2) / A2");

            FormulaError ef = (FormulaError)f.Evaluate(s => 0);
            Assert.AreEqual("divided by zero", ef.Reason);

            f = new Formula("2/0");

            ef = (FormulaError)f.Evaluate(s => 0);
            Assert.AreEqual("divided by zero", ef.Reason);
        }

        [TestMethod(), Timeout(5000)]
        public void OrderOperationsTest()
        {
            Formula f = new Formula("2+6*3");
            Assert.AreEqual(20f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        public void ParenthesisTimeTest()
        {
            Formula f = new Formula("2+3*5+(3+4*8)*5+2");
            Assert.AreEqual(194f, (double)f.Evaluate(s => 0), 1e-9);
        }

        [TestMethod(), Timeout(5000)]
        [ExpectedException(typeof(FormulaFormatException))]
        public void TestEmpty()
        {
            Formula f = new Formula("");

        }

        [TestMethod(), Timeout(5000)]
        public void ComplexMultiTest()
        {
            Formula f = new Formula("y1 * 3 - 8 / 2 + 4 * (8 - 9 * 2) / 14 * x7");
            Assert.AreEqual(5.142f, (double)f.Evaluate(s => (s == "x7") ? 1 : 4), 1e-3);
        }

        [TestMethod(), Timeout(5000)]
        public void testTest()
        {
            Formula f = new Formula("2/0*0*(3-3)");
            FormulaError ef = (FormulaError)f.Evaluate(s => 0);
            Assert.AreEqual("divided by zero", ef.Reason);
        }
    }
}