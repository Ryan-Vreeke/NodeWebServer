﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using SS;
using SpreadsheetUtilities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Xml;

namespace SpreadsheetPS4Test
{
    [TestClass]
    public class SpreadsheetTests
    {
        [TestMethod]
        public void ZeroArgumentConstructorTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();

            Assert.IsNotNull(s);

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void SetCellContentsInvalidNameTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("*2", "2");

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void SetCellContentsInvalidNameTextTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("*2", "Apple");

        }

        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void DifferentVersionLoadedTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A1", "name");
            s.SetContentsOfCell("B1", "is");

            s.Save("save.xml");
            AbstractSpreadsheet s1 = new Spreadsheet("save.xml", s => true, s => s.ToUpper(), "1.1");
        }

        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void LoadInvalidSpreadsheetNameTest()
        {
            using (XmlWriter writer = XmlWriter.Create("save.xml")) // NOTICE the file with no path
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("spreadsheet");
                writer.WriteAttributeString("version", "1.1");

                writer.WriteStartElement("cell");
                writer.WriteElementString("name", "");
                writer.WriteElementString("contents", "hello");
                writer.WriteEndElement();

                writer.WriteEndElement();
                writer.WriteEndDocument();
            }

            // NOTICE: opening the file created by this test (not a pre-existing file)
            AbstractSpreadsheet s1 = new Spreadsheet("save.xml", s => true, s => s.ToUpper(), "1.1");
        }
        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void LoadInvalidSpreadsheetCircularTest()
        {
            using (XmlWriter writer = XmlWriter.Create("save.xml")) // NOTICE the file with no path
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("spreadsheet");
                writer.WriteAttributeString("version", "1.1");

                writer.WriteStartElement("cell");
                writer.WriteElementString("name", "A1");
                writer.WriteElementString("contents", "=A1 * 2");
                writer.WriteEndElement();

                writer.WriteEndElement();
                writer.WriteEndDocument();
            }

            // NOTICE: opening the file created by this test (not a pre-existing file)
            AbstractSpreadsheet s1 = new Spreadsheet("save.xml", s => true, s => s.ToUpper(), "1.1");
        }

        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void LoadInvalidSpreadsheetInvalidNameTest()
        {
            using (XmlWriter writer = XmlWriter.Create("save.xml")) // NOTICE the file with no path
            {
                writer.WriteStartDocument();
                writer.WriteStartElement("spreadsheet");
                writer.WriteAttributeString("version", "1.1");

                writer.WriteStartElement("cell");
                writer.WriteElementString("name", "*2");
                writer.WriteElementString("contents", "=A1 * 2");
                writer.WriteEndElement();

                writer.WriteEndElement();
                writer.WriteEndDocument();
            }

            // NOTICE: opening the file created by this test (not a pre-existing file)
            AbstractSpreadsheet s1 = new Spreadsheet("save.xml", s => true, s => s.ToUpper(), "1.1");
        }

        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void LoadPathNotFoundTest()
        {

            // NOTICE: opening the file created by this test (not a pre-existing file)
            AbstractSpreadsheet s1 = new Spreadsheet("/some/nonsense/path.txt", s => true, s => s.ToUpper(), "1.1");
        }

        [TestMethod]
        public void SaveSpreadsheetTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A1", "name");
            s.SetContentsOfCell("B1", "is");
            s.SetContentsOfCell("C1", "=B1+1");

            s.Save("save.xml");
            AbstractSpreadsheet s1 = new Spreadsheet("save.xml", s => true, s => s.ToUpper(), "default");

            Assert.AreEqual(s.GetCellContents("A1"), s1.GetCellContents("A1"));
        }

        [TestMethod]
        public void GetSaveVersionTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("a1", "name");
            s.Save("save.xml");

            Assert.AreEqual("default", s.GetSavedVersion("save.xml"));
        }

        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void SaveNonExistingPathSpreadsheetTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A1", "name");
            s.SetContentsOfCell("B1", "is");

            s.Save("/some/nonsense/path.txt");
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void InvalidNameTestValidator()
        {
            AbstractSpreadsheet s = new Spreadsheet(s => false, s => s.ToUpper(), "1.1");
            s.SetContentsOfCell("*2", "Apple");

        }

        [TestMethod]
        [ExpectedException(typeof(SpreadsheetReadWriteException))]
        public void GetSaveVersionInvalidPathTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A1", "name");
            s.SetContentsOfCell("B1", "is");

            s.GetSavedVersion("/some/nonsense/path.txt");
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void SetCellContentsNullNameTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell(null, "2");

        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void GetCellValueNullNameTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.GetCellValue(null);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void GetCellContentsNullNameTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.GetCellContents(null);

        }


        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void TestInvalidNameTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("2A", "apple");

        }

        [TestMethod]
        public void SetCellContentsDoubleTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();

            Assert.IsTrue(s.SetContentsOfCell("A4", "2.5").Contains("A4"));
            Assert.AreEqual(2.5f, (double)s.GetCellContents("A4"), 1e-3);
        }

        [TestMethod]
        public void SetCellContentsTextTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();

            Assert.IsTrue(s.SetContentsOfCell("A4", "apple").Contains("A4"));
            Assert.AreEqual("apple", s.GetCellContents("A4"));

        }

        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SetCellContentsTextNullTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();

            s.SetContentsOfCell("A4", (string)null);

        }

        [TestMethod]

        public void GetCellContentTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A2", "2");
            s.SetContentsOfCell("A3", "4");
            s.SetContentsOfCell("A4", "3");

            Assert.AreEqual("3", s.GetCellContents("A4").ToString());
            Assert.AreEqual("4", s.GetCellContents("A3").ToString());
            Assert.AreEqual("2", s.GetCellContents("A2").ToString());
        }
        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void InvalidNameTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.GetCellContents("*SS");
        }
        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void InvalidNameValueTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.GetCellValue("*SS");
        }

        [TestMethod]

        public void NameOfEmptyCellTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            Assert.AreEqual("", s.GetCellContents("A1"));
        }
        [TestMethod]

        public void ValueOfEmptyCellTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            Assert.AreEqual("", s.GetCellValue("S1"));
        }

        [TestMethod]
        public void GetNamesOfAllNonemptyCellsTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A2", "2");
            s.SetContentsOfCell("A3", "4");
            s.SetContentsOfCell("A4", "3");

            IEnumerator e1 = s.GetNamesOfAllNonemptyCells().GetEnumerator();
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("A2", e1.Current);
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("A3", e1.Current);
            Assert.IsTrue(e1.MoveNext());
            Assert.AreEqual("A4", e1.Current);
            Assert.IsFalse(e1.MoveNext());
        }

        [TestMethod]
        public void SetCellContentsFormulaTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("C1", "=B1+A1");
            s.SetContentsOfCell("B1", "=A1*2");

            List<string> list = (List<string>)s.SetContentsOfCell("A1", "=2 * 3");

            Assert.AreEqual("A1", list[0]);
            Assert.AreEqual("B1", list[1]);
            Assert.AreEqual("C1", list[2]);
        }


        [TestMethod]
        [ExpectedException(typeof(ArgumentNullException))]
        public void SetCellContentsNullFormulatest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            string f = null;
            s.SetContentsOfCell("C1", f);
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void SetCellContentsNameValidTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            string f = "=2+3";
            s.SetContentsOfCell("*2", f);
        }

        [TestMethod]
        [ExpectedException(typeof(CircularException))]
        public void CircularGraphTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("B1", "=A1 * A1");
            s.SetContentsOfCell("C1", "=B1 + A1");
            s.SetContentsOfCell("D1", "=B1");
            s.SetContentsOfCell("A1", "=D1 + 2");

        }

        [TestMethod]
        public void FormulaValueTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("B1", "=A1 * A1");
            s.SetContentsOfCell("C1", "=B1 + A1");
            s.SetContentsOfCell("D1", "=B1");
            s.SetContentsOfCell("A1", "2");

            Assert.AreEqual(4f, (double)s.GetCellValue("B1"), 1e-9);

        }

        [TestMethod]
        public void FormulaChangeTest()
        {
            AbstractSpreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("B1", "=A1 * A1");
            s.SetContentsOfCell("A1", "2");

            Console.WriteLine(s.GetCellValue("B1"));
            Assert.AreEqual(2, s.SetContentsOfCell("A1", "=F1 + 1").Count);
            s.SetContentsOfCell("B1", "2");
            Assert.AreEqual(1, s.SetContentsOfCell("A1", "=E1 + 1").Count);
            s.SetContentsOfCell("B1", "=A1");
            Assert.AreEqual(2, s.SetContentsOfCell("A1", "=F1 + 1").Count);
        }

        [TestMethod()]
        [TestCategory("31")]
        public void TestStress1()
        {
            Spreadsheet s = new Spreadsheet();
            s.SetContentsOfCell("A1", "=B1+B2");
            s.SetContentsOfCell("B1", "=C1-C2");
            s.SetContentsOfCell("B2", "=C3*C4");
            s.SetContentsOfCell("C1", "=D1*D2");
            s.SetContentsOfCell("C2", "=D3*D4");
            s.SetContentsOfCell("C3", "=D5*D6");
            s.SetContentsOfCell("C4", "=D7*D8");
            s.SetContentsOfCell("D1", "=E1");
            s.SetContentsOfCell("D2", "=E1");
            s.SetContentsOfCell("D3", "=E1");
            s.SetContentsOfCell("D4", "=E1");
            s.SetContentsOfCell("D5", "=E1");
            s.SetContentsOfCell("D6", "=E1");
            s.SetContentsOfCell("D7", "=E1");
            s.SetContentsOfCell("D8", "=E1");
            IList<String> cells = s.SetContentsOfCell("E1", "0");
            Assert.IsTrue(new HashSet<string>() { "A1", "B1", "B2", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "E1" }.SetEquals(cells));
            Assert.AreEqual(0, (double)s.GetCellValue("A1"), 1e-4);
            s.SetContentsOfCell("D1", "2");
            cells = s.SetContentsOfCell("E1", "0");
            Assert.IsTrue(new HashSet<string>() { "A1", "B1", "B2", "C1", "C2", "C3", "C4", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "E1" }.SetEquals(cells));
            s.SetContentsOfCell("D1", "=E1");
            cells = s.SetContentsOfCell("E1", "0");
            Assert.IsTrue(new HashSet<string>() { "A1", "B1", "B2", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "E1" }.SetEquals(cells));
        }

        [TestMethod]
        public void NormalizeTest()
        {
            Spreadsheet s = new Spreadsheet(s => true, s => s.ToUpper(),"default");
            s.SetContentsOfCell("A1", "=B1+B2");
            s.SetContentsOfCell("B1", "=C1-C2");
            s.SetContentsOfCell("B2", "=C3*C4");
            s.SetContentsOfCell("C1", "=D1*D2");
            s.SetContentsOfCell("C2", "=D3*D4");
            s.SetContentsOfCell("C3", "=D5*D6");
            s.SetContentsOfCell("C4", "=D7*D8");
            s.SetContentsOfCell("d1", "=E1");
            s.SetContentsOfCell("d2", "=E1");
            s.SetContentsOfCell("d3", "=E1");
            s.SetContentsOfCell("d4", "=E1");
            s.SetContentsOfCell("d5", "=E1");
            s.SetContentsOfCell("d6", "=E1");
            s.SetContentsOfCell("d7", "=E1");
            s.SetContentsOfCell("d8", "=E1");
            IList<String> cells = s.SetContentsOfCell("E1", "0");
            Assert.IsTrue(new HashSet<string>() { "A1", "B1", "B2", "C1", "C2", "C3", "C4", "D1", "D2", "D3", "D4", "D5", "D6", "D7", "D8", "E1" }.SetEquals(cells));
        }

        [TestMethod]
        [ExpectedException(typeof(InvalidNameException))]
        public void ValidatorTest()
        {
            Spreadsheet s = new Spreadsheet(s => false, s => s.ToUpper(), "default");
            s.SetContentsOfCell("A1", "=B1+B2");
            s.SetContentsOfCell("B1", "=C1-C2");
            s.SetContentsOfCell("B2", "=C3*C4");
        }

        [TestMethod()]
        [TestCategory("35")]
        public void TestStress2()
        {
            Spreadsheet s = new Spreadsheet();
            ISet<String> cells = new HashSet<string>();
            for (int i = 1; i < 200; i++)
            {
                cells.Add("A" + i);
                Assert.IsTrue(cells.SetEquals(s.SetContentsOfCell("A" + i, "=A" + (i + 1))));
            }
        }

        [TestMethod()]
        [TestCategory("39")]
        public void TestStress3()
        {
            Spreadsheet s = new Spreadsheet();
            for (int i = 1; i < 200; i++)
            {
                s.SetContentsOfCell("A" + i, "=A" + (i + 1));
            }
            try
            {
                s.SetContentsOfCell("A150", "=A50");
                Assert.Fail();
            }
            catch (CircularException)
            {
            }
        }

        [TestMethod()]
        [TestCategory("43")]
        public void TestStress4()
        {
            Spreadsheet s = new Spreadsheet(s => true, s=>s.ToUpper(),"1.0") ;
            for (int i = 0; i < 250; i++)
            {
                s.SetContentsOfCell("A1" + i, "=A1" + (i + 1));
            }
            LinkedList<string> Cells = new LinkedList<string>();
            for (int i = 0; i < 250; i++)
            {
                Cells.AddFirst("A1" + i);

            }
            Assert.IsTrue(s.SetContentsOfCell("A1249", "25.0").SequenceEqual(Cells));
            s.Save("save.xml");

            Spreadsheet s1 = new Spreadsheet("save.xml",s => true, s=>s.ToUpper(),"1.0");
            Assert.AreEqual(s.GetCellValue("A1249"), s1.GetCellValue("A1249"));


        }

    }
}
