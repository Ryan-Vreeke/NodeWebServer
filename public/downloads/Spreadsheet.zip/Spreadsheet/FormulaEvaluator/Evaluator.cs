﻿using System;
using System.Collections;
using System.Text.RegularExpressions;
using System.Collections.Generic;

namespace FormulaEvaluator
{
    /// <summary>
    /// Evaluator class is a static class that contains a method to solve infix notations arithmaitc
    /// </summary>
    public static class Evaluator
    {
        //delegate to allow for different implementations of variable evaluations
        public delegate int Lookup(String v);//will not be implemented here 

        private static Stack<string> valueStack;
        private static Stack<string> operatorStack;

        /// <summary>
        ///  Evaluation takes in standard infix notation arithmatic problems, with or with out variables and will return the solution as an integer.
        ///  Evaluation doesn't support negative numbers
        /// </summary>
        /// <param name="exp"></param>
        /// <param name="variableEvaluator"></param>
        /// <returns></returns>
        public static int Evaluate(String exp, Lookup variableEvaluator)
        {
            valueStack = new Stack<string>();
            operatorStack = new Stack<string>();

            if (exp == null)
            {
                throw new ArgumentException("A null string was passed please pass in a non-null string");
            }

            string[] substrings = Regex.Split(exp.Replace(" ", string.Empty), "(\\()|(\\))|(-)|(\\+)|(\\*)|(/)");


            foreach (String t in substrings)//iterating through the equation left-right 
            {
                if (t != "")//when the string is split blank chars will be in substrings, so this just steps over those instantly to save time
                {

                    switch (t)
                    {

                        case var someVal when new Regex("^[0-9]+$").IsMatch(someVal)://is an integer
                            if (operatorStack.Count != 0)
                            {
                                //checking if operator on the stack is * or /
                                if (operatorStack.IsOnTop("*") || operatorStack.IsOnTop("/"))
                                {

                                    if (valueStack.Count != 0)// checking if valuestack is empty to avoid errors
                                    {

                                        valueStack.AddPush(valueStack.Pop(), t, operatorStack.Pop());//taking the top value of the value stack and applying the operator to it and t
                                    }
                                }
                                else
                                {
                                    valueStack.Push(t);// if the next operator isn't * or / then pushing t onto value stack
                                }
                            }
                            else
                            {
                                valueStack.Push(t);//pushing t to value stack because operator stack is empty
                            }
                            break;
                        case var someVal when new Regex(@"[a-zA-z][0-9]").IsMatch(someVal)://t is a variable
                            int tVar = 0;
                            try
                            {
                                tVar = variableEvaluator(t);
                            }
                            catch (Exception)
                            {

                                throw new ArgumentException("That Variable doesn't have a assigned value");
                            }

                            if (operatorStack.Count != 0)
                            {
                                //checking if operator on the stack is * or /
                                if (operatorStack.IsOnTop("*") || operatorStack.IsOnTop("/"))
                                {



                                    if (valueStack.Count != 0)// checking if valuestack is empty to avoid errors
                                    {

                                        valueStack.AddPush(valueStack.Pop(), "" + tVar, operatorStack.Pop());//taking the top value of the value stack and applying the operator to it and t
                                    }


                                }
                                else
                                {
                                    valueStack.Push("" + tVar);// if the next operator isn't * or / then pushing t onto value stack
                                }
                            }
                            else
                            {
                                valueStack.Push("" + tVar);//pushing t to value stack because operator stack is empty
                            }
                            break;
                        case var someVal when new Regex("(-)|(\\+)").IsMatch(someVal):
                            if (valueStack.Count >= 2 && operatorStack.RegexOnTop("(-)|(\\+)"))//checking if operatorstack isMatch with a regex
                            {
                                valueStack.AddPush(valueStack.Pop(), valueStack.Pop(), operatorStack.Pop());
                            }

                            operatorStack.Push(t);
                            break;
                        case var someVal when new Regex("(\\()|(\\*)|(/)").IsMatch(someVal):
                            operatorStack.Push(t);
                            break;
                        case var someVal when new Regex("(\\))").IsMatch(someVal):

                            if (operatorStack.IsOnTop("+") || operatorStack.IsOnTop("-"))
                            {
                                if (valueStack.Count >= 2)
                                {
                                    valueStack.AddPush(valueStack.Pop(), valueStack.Pop(), operatorStack.Pop());
                                }
                            }

                            if (operatorStack.IsOnTop("("))
                            {
                                operatorStack.Pop();

                            }
                            else
                            {
                                throw new ArgumentException();
                            }

                            if (operatorStack.IsOnTop("*") || operatorStack.IsOnTop("/"))
                            {
                                valueStack.AddPush(valueStack.Pop(), valueStack.Pop(), operatorStack.Pop());
                            }


                            break;

                        default://if the char isn't a "" and isn't any of the prior char then an ArgumentExceptions is thrown
                            throw new ArgumentException("Char \"" + t + "\" is not a valid character");
                            break;
                    }
                }
            }

            if (operatorStack.Count == 0)
            {
                if (valueStack.Count == 0 || valueStack.Count != 1)
                {
                    throw new ArgumentException("Missing Values in the given string");
                }
                else
                {

                    return valueStack.ReturnPop();
                }
            }
            else
            {
                try
                {

                    valueStack.AddPush(valueStack.Pop(), valueStack.Pop(), operatorStack.Pop());
                }
                catch (Exception)
                {
                    throw new ArgumentException("There isn't exactly one of the right type on the operator stack or exactly two numbers on the value stack");
                }
            }

            if (valueStack.Count != 1)
            {
                throw new ArgumentException();
            }
            else
            {
                return valueStack.ReturnPop();

            }



        }
    }

    /// <summary>
    /// ps1 specific stack extension class to contain helper methods
    /// </summary>
    static class PS1StackExtensions
    {
        /// <summary>
        /// parses the popped value into an int then returns if stack s isn't empty;
        /// </summary>
        /// <param name="s"></param>
        /// <returns></returns>
        public static int ReturnPop(this Stack<string> s)
        {
            if (s.Count != 0)
            {
                return int.Parse(s.Pop());
            }
            else
            {
                throw new ArgumentException("Inappropriate number of values in stack");
            }
        }

        /// <summary>
        /// Checks if stack is not empty and contains a string c
        /// </summary>
        /// <param name="s"></param>
        /// <param name="c"></param>
        /// <returns></returns>
        public static bool IsOnTop(this Stack<string> s, string c)
        {
            return s.Count > 0 && s.Peek() == c;
        }

        /// <summary>
        /// Check if a char is on top of a stack using regex, while controlling for possible errors
        /// </summary>
        /// <param name="s"></param>
        /// <param name="reg"></param>
        /// <returns></returns>
        public static bool RegexOnTop(this Stack<string> s, string reg)
        {
            return s.Count > 0 && Regex.IsMatch(s.Peek(), reg);
        }

        /// <summary>
        /// takes two values in as strings, turns the values into ints and applies the operator then will push the result onto the stack
        /// </summary>
        /// <param name="s"></param>
        /// <param name="val"></param>
        /// <param name="val1"></param>
        /// <param name="op"></param>
        public static void AddPush(this Stack<string> s, string val, string val1, string op)
        {
            int v = int.Parse(val);
            int v1 = int.Parse(val1);

            Console.WriteLine(v + " " + op + " " + v1);

            switch (op)
            {
                case "+":
                    s.Push("" + (v1 + v));
                    break;
                case "-":
                    s.Push("" + (v1 - v));
                    break;
                case "*":
                    s.Push("" + (v * v1));
                    break;
                case "/":
                    if (v1 != 0)
                    {
                        s.Push("" + (v / v1));

                    }
                    else
                    {
                        throw new ArgumentException("A Division By Zero Occured!");
                    }
                    break;
            }


        }

    }
}
