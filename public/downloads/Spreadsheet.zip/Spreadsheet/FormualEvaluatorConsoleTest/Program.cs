﻿using System;
using FormulaEvaluator;
using System.Text.RegularExpressions;
using System.Collections.Generic;
using SpreadsheetUtilities;
using SS;
using System.Xml;

namespace FormualEvaluatorConsoleTest
{
    class Program
    {
        static void Main(string[] args)
        {
            int x = 1;
            int[] array = new int[10];
            array[0] = x;
            T(out array[0]);

            Console.WriteLine(x);
        }

        public static void T(out int x)
        {
            x = 10;
        }
    }
}


