﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;
using SpreadsheetUtilities;

namespace SS
{
    /// <summary>
    /// Cell class contains a cells name a value so it can be referenced in other data applications.
    /// each cell has a name, each cell has a contents and a value.  The distinction is important.
    /// 
    /// </summary>
    public class Cell
    {
        private object pContent;
        private object pValue;
        public object Content
        {
            get { return pContent; }
            set
            {
                pContent = value;
            }
        }

        public object Value
        {
            get
            {
                return pValue;
            }
            set
            {
                pValue = value;
            }
        }
        /// <summary>
        /// creates an empty cell with both the value and content set to an empty string
        /// </summary>
        public Cell()
        {
            pContent = "";
            pValue = "";
            //valid Contents of a cell can be (1) a string, (2) a double, or (3) a Formula
        }

        /// <summary>
        /// writes cell to an existing xmlwriter
        /// </summary>
        /// <param name="writer"></param>
        public void WriteXml(XmlWriter writer, string name)
        {
            writer.WriteStartElement("cell");//starts the cell block

            writer.WriteElementString("name", name);
            //puts all the information about the cell in to the element
            if (Content.GetType() == typeof(Formula))
                writer.WriteElementString("contents", "=" + Content.ToString());
            else
                writer.WriteElementString("contents", Content.ToString());
            writer.WriteEndElement();//Ends the cell block 
        }
    }
}
