﻿///Written By Ryan Vreeke
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;
using System.Xml;
using SpreadsheetUtilities;


namespace SS
{
    public class Spreadsheet : AbstractSpreadsheet
    {
        public override bool Changed { get => pChanged; protected set => pChanged = value; }
        private bool pChanged;
        private Dictionary<string, Cell> cells;
        private DependencyGraph dg;

        /// <summary>
        /// zero-argument constructor that create an empty spreadsheet that imposes no extra validity conditions, 
        /// normalizes every cell name to itself, and has version "default".
        /// </summary>
        public Spreadsheet() : base(s => true, s => s, "default")
        {
            cells = new Dictionary<string, Cell>();
            dg = new DependencyGraph();
            Changed = false;
        }

        /// <summary>
        /// Three argument constructor. that calls the constructor inherited from ABstractSpreadsheet
        /// </summary>
        /// <param name="isValid"></param>
        /// <param name="normalize"></param>
        /// <param name="version"></param>
        public Spreadsheet(Func<string, bool> isValid, Func<string, string> normalize, string version) : base(isValid, normalize, version)
        {
            cells = new Dictionary<string, Cell>();
            dg = new DependencyGraph();
            Changed = false;
        }

        /// <summary>
        ///  It should read a saved spreadsheet from the file (see the Save method) and use it to construct a new spreadsheet. 
        ///  The new spreadsheet should use the provided validity delegate, normalization delegate, and version.
        /// </summary>
        /// <param name="filePath"></param>
        /// <param name="isValid"></param>
        /// <param name="normalize"></param>
        /// <param name="version"></param>
        public Spreadsheet(string filePath, Func<string, bool> isValid, Func<string, string> normalize, string version) : base(isValid, normalize, version)
        {
            cells = new Dictionary<string, Cell>();
            dg = new DependencyGraph();
            /*
             If anything goes wrong when reading the file, the constructor should throw a SpreadsheetReadWriteException with an explanatory message. For example:
                If the version of the saved spreadsheet does not match the version parameter provided to the constructor
                If any of the names contained in the saved spreadsheet are invalid
                If any invalid formulas or circular dependencies are encountered
                If there are any problems opening, reading, or closing the file (such as the path not existing)
                There are no doubt other things that can go wrong
             */
            if (GetSavedVersion(filePath) == version)
            {
                ReadSpreadsheet(filePath);
            }
            else
                throw new SpreadsheetReadWriteException("Version of saved file doesn't match current version");
            Changed = false;
        }

        public override object GetCellContents(string name)
        {
            name = Normalize(name);
            if (name == null || !IsValidName(name))//check if it is a valid name
            {
                throw new InvalidNameException();
            }
            if (cells.ContainsKey(name))//check if name is empty, names that are in cells keys are not empty
            {
                return cells[name].Content;//return nonempty cells contents
            }
            else
            {
                return "";//because the name isn't filled return an empty string;
            }
        }

        public override object GetCellValue(string name)
        {
            if (name == null || !IsValidName(name))
            {
                throw new InvalidNameException();
            }

            name = Normalize(name);
            if (cells.ContainsKey(name))//if name is a key in cells then it has content and will have an assigned value 
            {
                return cells[name].Value;
            }
            else // if name isn't in cells then it doesn't have content and wont have a value so return an empty string
            {
                return "";
            }
        }

        public override IEnumerable<string> GetNamesOfAllNonemptyCells()
        {
            return cells.Keys;
        }
        // ADDED FOR PS5
        /// <summary>
        /// Returns the version information of the spreadsheet saved in the named file.
        /// If there are any problems opening, reading, or closing the file, the method
        /// should throw a SpreadsheetReadWriteException with an explanatory message.
        /// </summary>
        public override string GetSavedVersion(string filename)
        {
            string savedVersion = "";//created a temp string to return saved file's version
            try
            {
                using (XmlReader reader = XmlReader.Create(filename))//create an XmlReader inside this block and will Dispose at the end
                {
                    while (reader.Read())
                    {
                        if (reader.IsStartElement())
                        {
                            switch (reader.Name)
                            {
                                case "spreadsheet":
                                    savedVersion = reader["version"];
                                    break;
                            }
                        }
                    }
                }
            }
            catch (DirectoryNotFoundException)//wasn't able to read from filename so throw an exception
            {
                throw new SpreadsheetReadWriteException("could not read from Path " + filename);
            }
            catch (Exception)
            {
                throw new SpreadsheetReadWriteException("A problem happened");
            }
            return savedVersion;
        }

        public override void Save(string filename)
        {
            //changing xml setting to make the xml more readable.
            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;
            settings.IndentChars = "  ";

            //Create an XmlWriter inside this block, and Dispose at the end
            try
            {
                using (XmlWriter writer = XmlWriter.Create(filename, settings))
                {
                    writer.WriteStartDocument();
                    writer.WriteStartElement("spreadsheet");
                    //adding an attribute to the spreadsheet element specifically the version
                    writer.WriteAttributeString("version", Version);

                    writer.WriteStartElement("cells");//start cells element

                    //write nonempty cells
                    foreach (string s in GetNamesOfAllNonemptyCells())
                        GetCell(s).WriteXml(writer, s);

                    writer.WriteEndElement();//ends cells block
                    writer.WriteEndElement();//ends spreadsheet block
                    writer.WriteEndDocument();
                }
            }
            catch (DirectoryNotFoundException)
            {
                throw new SpreadsheetReadWriteException("The File Path given was invalid");
            }
            Changed = false;
        }

        public override IList<string> SetContentsOfCell(string name, string content)
        {
            //checking if content and name are valid
            if (content == null)
                throw new ArgumentNullException();
            else if (name == null || !IsValidName(name))
                throw new InvalidNameException();

            Changed = true;
            //because name is valid at this point i can normalize name and pass normalized name into the other setcell methods
            name = Normalize(name);
            if (IsDouble(content))//check if content is double so I know what set cell method to call
                return SetCellContents(name, double.Parse(content));
            else if (IsFormula(content))//using '=' at the begining of content to determin to use formula or not
                return SetCellContents(name, new Formula(content.Substring(1), Normalize, IsValid));
            else
                return SetCellContents(name, content);//using text set cell content because content isn't number or formula
        }

        protected override IEnumerable<string> GetDirectDependents(string name)
        {
            return dg.GetDependents(name);//returns the dependents of name
        }

        protected override IList<string> SetCellContents(string name, double number)
        {
            RemoveDependees(name);
            AddNewCell(name, number);// making a new cell or changing content of an existing cell
            List<string> dependents = new List<string>();
            GetIndirectDependents(dependents, name);//getting all of the indirect dependents
            RecalculateCells(dependents);

            return dependents;
        }

        protected override IList<string> SetCellContents(string name, string text)
        {
            RemoveDependees(name);
            AddNewCell(name, text);//making a new cell or changeing content of an old cell
            List<string> dependents = new List<string>();
            GetIndirectDependents(dependents, name);
            RecalculateCells(dependents);

            return dependents;
        }

        protected override IList<string> SetCellContents(string name, Formula formula)
        {
            List<string> dependents = new List<string>();//list of dependents that will be returned
            RemoveDependees(name);//removing any pre existing dependencys

            BuildDG(name, formula);//building new dependencys

            if (!IsCircular(formula))//checking if formula would cause circular graph
            {
                AddNewCell(name, formula);//make a new cell with formula as the content
            }
            else//because a circular graph was made I am removing all the dependencys that were made
            {
                RemoveDependees(name);

                throw new CircularException();
            }

            GetIndirectDependents(dependents, name);//indirect dependent helper method
            RecalculateCells(dependents);
            return dependents;
        }

        //Helper methods
        /// <summary>
        /// checks if the name passed in is valid based on internal standards for a spreadsheet and if it is valid based on delegates standards for a name
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private bool IsValidName(string name)
        {
            if (Regex.IsMatch(name, "^[a-zA-Z]+[0-9]+$") && IsValid(name))//check if name is one or more letters followed by one or more numbers
                return true;
            else
                return false;
        }

        private void BuildDG(string name, Formula formula)
        {
            foreach (string s in formula.GetVariables())//for each variable in the formula
            {
                dg.AddDependency(s, name);//add a dependency
            }
        }

        private void RemoveDependees(string name)
        {
            if (dg.HasDependees(name))
            {
                dg.ReplaceDependees(name, new HashSet<string>());
            }
        }

        private double ValueLookUp(string name)
        {
            if (cells.ContainsKey(name))
            {
                string value = cells[name].Value.ToString();

                if (IsDouble(value))
                    return double.Parse(value);
                else
                    throw new ArgumentException();
            }
            else
            {
                throw new ArgumentException();
            }
        }

        /// <summary>
        /// helper method to create a new cell and add it to the dictionary. if the name of the cell isn't empty then remove the old cell and place a new one
        /// </summary>
        /// <param name="name"></param>
        /// <param name="content"></param>
        private void AddNewCell(string name, object content)
        {
            Cell tempCell = new Cell();
            if (cells.ContainsKey(name))
            {
                cells.Remove(name);
            }
            cells.Add(name, new Cell());
            cells[name].Content = content;

        }
        /// <summary>
        /// returns the cell object that is saved in the dictionary
        /// </summary>
        /// <param name="name"></param>
        /// <returns></returns>
        private Cell GetCell(string name)
        {
            return cells[name];
        }

        public void RecalculateCells(List<string> dependents)
        {
            foreach (string s in dependents)
            {
                object content = GetCellContents(s);
                if (IsFormula(content))
                {
                    cells[s].Value = GetEvaluatedFormula((Formula)content);
                }
                else
                {
                    cells[s].Value = content;
                }
            }
        }

        /// <summary>
        /// evaluates a formula and returns either a double or FormulaError 
        /// </summary>
        /// <param name="Content"></param>
        /// <returns></returns>
        private object GetEvaluatedFormula(Formula Content)
        {
            return Content.Evaluate(ValueLookUp);
        }

        /// <summary>
        /// uses the inherited method GetCellsToRecalculate to add all the dependents to the list of dependents starting from name
        /// </summary>
        /// <param name="dependents"></param>
        /// <param name="name"></param>
        private void GetIndirectDependents(List<string> dependents, string name)
        {
            foreach (string s in GetCellsToRecalculate(name))
            {
                dependents.Add(s);
            }
        }
        /// <summary>
        /// Returns true if content if content is a double
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        private bool IsDouble(string content)
        {
            return double.TryParse(content, out double result);
        }
        /// <summary>
        /// Returns true if content is a f
        /// </summary>
        /// <param name="content"></param>
        /// <returns></returns>
        private bool IsFormula(object content)
        {
            return content.ToString().StartsWith("=") || content.GetType() == typeof(Formula);
        }

        /// <summary>
        /// Does a check if the formual would cause a circular dependencyGraph, returns false if the method completes
        /// </summary>
        /// <param name="formula"></param>
        /// <returns></returns>
        private bool IsCircular(Formula formula)
        {
            IEnumerator<string> e = formula.GetVariables().GetEnumerator();//all the variables in the formula

            while (e.MoveNext())//while there is a variable in the formula
            {
                //uses getcellstorecalculate to check if the current variable has a circular dependency.
                try
                {
                    GetCellsToRecalculate(e.Current);//if GetCellsToRecalculate doesn't throw a circularexception then that variable wouldn't cause a problem
                }
                catch (CircularException)
                {
                    return true;
                }
            }

            return false;//all the variables in formula have been checked at this point and if the code gets here than it isn't a problem and can return false

        }
        /// <summary>
        /// Helper method to read the xml of a spreadsheet and parse the data into usable information
        /// </summary>
        /// <param name="filename"></param>
        private void ReadSpreadsheet(string filename)
        {

            string content = null;
            string name = null;

            using (XmlReader reader = XmlReader.Create(filename))
            {
                while (reader.Read())
                {
                    if (reader.IsStartElement())
                    {
                        switch (reader.Name)
                        {
                            case "cell":

                                break;
                            case "name":
                                reader.Read();
                                name = reader.Value;
                                break;
                            case "contents":
                                reader.Read();
                                content = reader.Value;
                                break;
                        }
                    }
                    else
                    {
                        if (reader.Name == "cell")
                        {
                            try
                            {
                                SetContentsOfCell(name, content);
                            }
                            catch (InvalidNameException)
                            {
                                throw new SpreadsheetReadWriteException("Name of saved cell (" + reader.Value + ") isn't valid");
                            }
                            catch (ArgumentNullException)
                            {
                                throw new SpreadsheetReadWriteException("Contents can't be null");
                            }
                            catch (CircularException)
                            {
                                throw new SpreadsheetReadWriteException("A circular graph was created");
                            }
                        }
                    }
                }
            }
        }
    }
}
